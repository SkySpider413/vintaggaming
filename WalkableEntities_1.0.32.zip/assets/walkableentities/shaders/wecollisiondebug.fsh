#version 330 core
out vec4 outColor;
void main() { outColor = vec4(0.2, 1.0, 0.85, 1.0); }
