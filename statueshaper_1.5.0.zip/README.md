# Statue Shaper

A Vintage Story 1.22+ code mod. Place a frame, pick a blueprint, chalk the cuts, and chisel
your way to a beautiful statue.

Statue Shaper helps you turn rough blocks into statues. Place modular statue frames, attach a
controller, pick a voxel blueprint from the GUI, then use the Marking Line tool to chalk the
voxels you need to chisel away. Carve along the lines and your statue takes shape.

## Features

- Modular frame/controller assembly across multiple tiers
- Two-tab controller GUI: a blueprint picker (Build) and a Capture tab
- Capture tab turns whatever you've built on the frames into a new blueprint, with a live preview and rotate/mirror controls
- Blueprint picker with an in-game preview and blueprint library
- Marking Line tool draws colored chalk lines around the voxels to chisel
- Water bucket and rain erase chalk marks
- In-game mesh (`.stl` and `.obj`) to blueprint (`.cbp`) converter with GUI
- Client/server blueprint sync: upload your own blueprint files in-game

## Companion content

This mod does not include any statues. Load your own, or add the companion mods for more content:

- **[Statues Extended Holy](https://mods.vintagestory.at/statuesextendedholy)**: angels, divine
  beings, holy figures.

## Installing

Drop the `.zip` into your Vintage Story `Mods` folder and restart the game (or reload the world).

## Building from source

```
./build.sh            # build (Release) + install into VS Mods folder
./build.sh --zip      # also produce a distributable zip in build/
```

See `CLAUDE.md` for toolchain requirements and build gotchas.
