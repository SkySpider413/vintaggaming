# Attribution and provenance

Hearth & Draught is maintained by CreeperHost.

It contains adapted code and assets from these projects by MissesHex/sknep:

- Sliding Windows: https://github.com/sknep/vintage-story-sliding-windows
- Glass Doors: https://github.com/sknep/vintage-story-glass-doors
- Glass Trapdoors: https://github.com/sknep/vintage-story-glass-trapdoors

Those projects and this continuation are distributed under Creative Commons
Attribution-ShareAlike 4.0 International. The full licence is included as `LICENSE.md`.
The project links above identify the sources of the adapted code and assets.
