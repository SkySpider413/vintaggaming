# Hearth & Draught

Hearth & Draught brings windows, doors, chimneys and solid-fuel heating together in Vintage Story.

I grew up around farms and older buildings, so heating meant AGAs, log burners and open fires rather than a campfire in the middle of the floor. It always felt odd that a Vintage Story room could stay comfortable through a bitter winter without a proper heat source, while there was very little you could build to heat it properly.

Windows, draught, chimneys, fuel and heat are all parts of the same building. This mod is my attempt to make them behave that way.

## What is included

- Fixed and sliding windows in wood and metal frames
- Clear, coloured and leaded glazing
- Glass doors, glass trapdoors and half-glazed stable doors
- Tilting skylights in 1x1, 2x2 and 4x4 sizes
- Fire-clay log burners and large heat-storage ranges
- Open-fire grates that join into runs up to four blocks wide
- Metal and fired-clay flues, elbows, dampers and chimney pots
- Room airflow, cross-ventilation, modest open-window cooling and drying support
- Ash, hot cinders, cinder crocks and reusable pocket warmers
- Oil/fat greenhouse heaters for wall or ceiling mounting
- Room and local fire warmth shown as Ambient Temperature in the character menu

Most controls are on the blocks themselves. Doors, vents, lids and dampers are operated in the world rather than through a settings screen.

## Installing

Install the release zip in the `Mods` folder on both the client and server. Do not unpack it.

Built for Vintage Story 1.22.6 and 1.22.7. Back up an existing world before installing it.

## Configuration and compatibility

Major feature groups can be switched off separately. Balance values live in a commented JSON5 config so server owners can see what each option does.

RealSmoke, DryingSpeedOverhaul, ConfigLib and ConfigKit have optional integrations; none of them are required. If both configuration editors are installed, ConfigLib owns the settings screen. The mod works on any host.

The 2.0.0 beta series contains the planned feature set and is for player testing, not a final release. Beta.2 repairs the ceramic forming and pit-kiln workflow that was missed in beta.1. Update the client and server together, and keep a backup of your world and configuration. See the beta.2 notes for the changes, verified coverage and testing limits.

## Credits

Hearth & Draught continues the Sliding Windows, Glass Doors and Glass Trapdoors mods by MissesHex/sknep. The original work is credited in `NOTICE.md`.

## About CreeperHost

CreeperHost started with Minecraft players hosting servers for the communities we played in ourselves. We grew by making useful things, being honest with people and sticking around. That is the approach we are bringing to Vintage Story too.

There are no server adverts in the mod and it works on any host. We would rather make something good enough that you remember who made it. If you need a Vintage Story server later, now you know who we are.

The mod is free and released under Creative Commons Attribution-ShareAlike 4.0. See `NOTICE.md` for attribution.
