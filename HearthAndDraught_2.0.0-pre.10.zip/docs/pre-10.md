# 2.0.0-pre.10

I've fixed the room-temperature link with Immersive Body Temperature 1.8.0 and updated the smoke integration for Real Smoke 2.0.0-pre.11. Thanks to lunardiver for pointing both of those out.

- IBT now gets the temperature of our heated or cooled room properly. Its water-temperature handling and body-temperature settings are still its own.
- Updated the flue pumps and chimney exhaust for Real Smoke's new smoke simulation. Closed dampers and blocked chimney pots still stop the route working; they don't magically let smoke through.
- The range's hotplate lids now open towards the back, so you can see the cookware from the front. Thanks to nickzom and DoctorLife for that suggestion.
- Fixed the range refusing to light with Blush and Bins installed. Its firebox clicks were being redirected to the wood rack, which understandably wasn't having any of it.
- Added angled roof flue sleeves. Shift-right-click a placed sleeve with an empty hand to cycle through the pitches and directions.
- Metal flues give off a little warmth in other enclosed rooms along their route while the fire is burning. Don't expect them to replace a radiator.
- Greenhouse heaters now accept Aqua Vitae, giving one day per litre. Oil and fat still give two days per litre.

The compatibility and range checks passed on VS 1.22.6 and 1.22.7 with IBT 1.8.0 and Real Smoke 2.0.0-pre.11 together. That's not a promise that every mod combination works.

Central heating is still extremely early and barely tested in normal gameplay. Keep backups, and don't rely on it as your only way of staying warm.
