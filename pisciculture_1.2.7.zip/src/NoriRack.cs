using System;
using System.Collections.Generic;
using System.Text;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Config;
using Vintagestory.API.Datastructures;
using Vintagestory.API.MathTools;
using Vintagestory.API.Server;
using Vintagestory.GameContent;

namespace Pisciculture
{
    /// <summary>
    /// Cavalete de secagem de nori: montado por etapas (6 gravetos, 3 amarracoes de papiro/junco, 2 paineis).
    /// Cada painel tem 4 lugares para pasta de alga; a pasta seca ao sol dos dois lados.
    /// </summary>
    public class BlockNoriRack : Block
    {
        public override Cuboidf[] GetSelectionBoxes(IBlockAccessor blockAccessor, BlockPos pos)
        {
            string o = Variant != null && Variant.ContainsKey("horizontalorientation") ? Variant["horizontalorientation"] : "north";
            float rot = o == "east" ? 270 : o == "south" ? 180 : o == "west" ? 90 : 0;
            Cuboidf[] b = new Cuboidf[]
            {
                new Cuboidf(0.0f, 0.50f, 0.15f, 1.0f, 1.00f, 0.80f),
                new Cuboidf(0.0f, 0.00f, 0.15f, 1.0f, 0.50f, 1.15f)
            };
            if (rot != 0)
            {
                for (int i = 0; i < b.Length; i++) b[i] = b[i].RotatedCopy(0, rot, 0, new Vec3d(0.5, 0.5, 0.5));
            }
            return b;
        }

        public override bool CanPlaceBlock(IWorldAccessor world, IPlayer byPlayer, BlockSelection blockSel, ref string failureCode)
        {
            if (!base.CanPlaceBlock(world, byPlayer, blockSel, ref failureCode)) return false;
            Block below = world.BlockAccessor.GetBlock(blockSel.Position.DownCopy());
            if (!below.SideSolid[BlockFacing.UP.Index])
            {
                failureCode = "requiresolidground";
                return false;
            }
            return true;
        }

        public override void OnNeighbourBlockChange(IWorldAccessor world, BlockPos pos, BlockPos neibpos)
        {
            base.OnNeighbourBlockChange(world, pos, neibpos);
            if (world.Side != EnumAppSide.Server) return;
            Block below = world.BlockAccessor.GetBlock(pos.DownCopy());
            if (!below.SideSolid[BlockFacing.UP.Index]) world.BlockAccessor.BreakBlock(pos, null);
        }

        public override bool OnBlockInteractStart(IWorldAccessor world, IPlayer byPlayer, BlockSelection blockSel)
        {
            BlockEntityNoriRack be = world.BlockAccessor.GetBlockEntity(blockSel.Position) as BlockEntityNoriRack;
            if (be != null) return be.OnInteract(byPlayer, blockSel);
            return base.OnBlockInteractStart(world, byPlayer, blockSel);
        }

        public override WorldInteraction[] GetPlacedBlockInteractionHelp(IWorldAccessor world, BlockSelection selection, IPlayer forPlayer)
        {
            return new WorldInteraction[]
            {
                new WorldInteraction { ActionLangCode = "pisciculture:blockhelp-norirack-build", MouseButton = EnumMouseButton.Right },
                new WorldInteraction { ActionLangCode = "pisciculture:blockhelp-norirack-take", MouseButton = EnumMouseButton.Right, HotKeyCode = "shift" }
            };
        }
    }

    public class BlockEntityNoriRack : BlockEntityDisplay
    {
        // Etapas concluidas: 1..9 gravetos, 10..13 amarracoes (taboa/papiro), 14 = esteira colocada (pronto).
        public const int SticksNeeded = 9;
        public const int TiesNeeded = 4;
        public const int StageFrontPanel = SticksNeeded + TiesNeeded;   // 13: falta so a esteira
        public const int StageComplete = StageFrontPanel + 1;           // 14: pronto
        public const int SlotCount = 6;
        
        static readonly string[][] StageElements = new string[][]
        {
            new string[] { "u1" },
            new string[] { "u2" },
            new string[] { "h1" },
            new string[] { "h2" },
            new string[] { "d1" },
            new string[] { "d2" },
            new string[] { "c1" },
            new string[] { "c2" },
            new string[] { "g", "g_r0", "g_r1", "g_r2", "g_r3", "g_r4", "g_r5", "g_r6", "g_r7", "g_r8", "g_r9", "g_r10", "g_r11", "g_r12", "g_r13", "g_r14", "g_r15" },
            new string[] { "t1_0", "t1_1", "t1_2", "t1_3", "t1_4", "t1_5", "t1_6", "t1_7", "t1_8", "t1_9", "t1_10", "t1_11", "t1_12", "t1_13", "t1_14", "t1_15", "t1_16", "t1_17", "t1_18", "t1_19", "t1_20", "t1_21", "t1_22", "t1_23", "t1_24", "t1_25", "t1_26", "t1_27", "t1_28", "t1_29", "t1_30", "t1_31", "t1_32", "t1_33", "t1_34", "t1_35", "t1_36", "t1_37", "t1_38", "t1_39" },
            new string[] { "t2_0", "t2_1", "t2_2", "t2_3", "t2_4", "t2_5", "t2_6", "t2_7", "t2_8", "t2_9", "t2_10", "t2_11", "t2_12", "t2_13", "t2_14", "t2_15", "t2_16", "t2_17", "t2_18", "t2_19", "t2_20", "t2_21", "t2_22", "t2_23", "t2_24", "t2_25", "t2_26", "t2_27", "t2_28", "t2_29", "t2_30", "t2_31", "t2_32", "t2_33", "t2_34", "t2_35", "t2_36", "t2_37", "t2_38", "t2_39" },
            new string[] { "t3_0", "t3_1", "t3_2", "t3_3", "t3_4", "t3_5", "t3_6", "t3_7", "t3_8", "t3_9", "t3_10", "t3_11", "t3_12", "t3_13", "t3_14", "t3_15", "t3_16", "t3_17", "t3_18", "t3_19", "t3_20", "t3_21", "t3_22", "t3_23", "t3_24", "t3_25", "t3_26", "t3_27", "t3_28", "t3_29", "t3_30", "t3_31", "t3_32", "t3_33", "t3_34", "t3_35", "t3_36", "t3_37", "t3_38", "t3_39", "t3_40", "t3_41", "t3_42", "t3_43", "t3_44", "t3_45", "t3_46", "t3_47", "t3_48", "t3_49", "t3_50", "t3_51" },
            new string[] { "t4_0", "t4_1", "t4_2", "t4_3", "t4_4", "t4_5", "t4_6", "t4_7", "t4_8", "t4_9", "t4_10", "t4_11", "t4_12", "t4_13", "t4_14", "t4_15", "t4_16", "t4_17", "t4_18", "t4_19", "t4_20", "t4_21", "t4_22", "t4_23", "t4_24", "t4_25", "t4_26", "t4_27", "t4_28", "t4_29", "t4_30", "t4_31", "t4_32", "t4_33", "t4_34", "t4_35", "t4_36", "t4_37", "t4_38", "t4_39", "t4_40", "t4_41", "t4_42", "t4_43", "t4_44", "t4_45", "t4_46", "t4_47", "t4_48", "t4_49", "t4_50", "t4_51" },
            new string[] { "pn" }
        };

        InventoryGeneric inv;
        int stage;
        string tieCode;
        MeshData frameMesh;
        int frameMeshStage = -1;

        public override InventoryBase Inventory => inv;
        public override string InventoryClassName => "norirack";
        public override string AttributeTransformCode => "onNoriRackTransform";
        public override int DisplayedItems => SlotCount;

        public BlockEntityNoriRack()
        {
            inv = new InventoryGeneric(SlotCount, "norirack-0", null, (NewSlotDelegate)null);
        }

        public override void Initialize(ICoreAPI api)
        {
            base.Initialize(api);
            inv.LateInitialize("norirack-" + Pos.X + "/" + Pos.Y + "/" + Pos.Z, api);
            inv.OnAcquireTransitionSpeed += Inv_OnAcquireTransitionSpeed;
        }

        float RotateY
        {
            get
            {
                string o = Block.Variant != null && Block.Variant.ContainsKey("horizontalorientation") ? Block.Variant["horizontalorientation"] : "north";
                switch (o)
                {
                    case "east": return 270f;
                    case "south": return 180f;
                    case "west": return 90f;
                    default: return 0f;
                }
            }
        }

        // ---------------- secagem ----------------

        string lastCondition = "good";

        float Inv_OnAcquireTransitionSpeed(EnumTransitionType transType, ItemStack stack, float baseMul)
        {
            if (transType != EnumTransitionType.Dry) return baseMul;
            // Base do InWorldContainer para Dry = 0.25; multiplicamos para que 1 hora de sol pleno conte como 1 hora de secagem.
            return baseMul * 4f * DryingFactor();
        }

        float cachedFactor;
        long cachedAtMs = -100000;

        float DryingFactor()
        {
            if (Api == null) return 0f;
            // O clima so muda devagar: reaproveita o calculo por 1 s (cada espaco da esteira consulta isto).
            long nowMs = Api.World.ElapsedMilliseconds;
            if (nowMs - cachedAtMs < 1000) return cachedFactor;
            cachedAtMs = nowMs;
            cachedFactor = ComputeDryingFactor();
            return cachedFactor;
        }

        float ComputeDryingFactor()
        {
            float light = 0f;
            try { light = GameMath.Clamp(Api.World.BlockAccessor.GetLightLevel(Pos, EnumLightLevelType.TimeOfDaySunLight) / 20f, 0f, 1f); }
            catch { light = GameMath.Clamp(Api.World.Calendar.GetDayLightStrength(Pos.X, Pos.Z), 0f, 1f); }
            if (light <= 0.05f) { lastCondition = "night"; return 0f; }

            ClimateCondition cl = Api.World.BlockAccessor.GetClimateAt(Pos, EnumGetClimateMode.NowValues);
            if (cl == null) { lastCondition = "good"; return light; }

            bool openSky = Api.World.BlockAccessor.GetRainMapHeightAt(Pos.X, Pos.Z) <= Pos.Y;
            if (openSky && cl.Rainfall > 0.15f) { lastCondition = "rain"; return 0f; }
            if (cl.Temperature < -2f) { lastCondition = "cold"; return 0f; }

            light *= GameMath.Clamp((cl.Temperature + 2f) / 18f, 0.3f, 1f);
            lastCondition = light < 0.6f ? "partial" : "good";
            return light;
        }

        // ---------------- helpers de itens ----------------

        static bool IsPaste(ItemStack s, string state)
        {
            return s != null && s.Collectible?.Code != null && s.Collectible.Code.Domain == "pisciculture" && s.Collectible.Code.Path == "algapaste-" + state;
        }
        static bool IsFresh(ItemStack s) { return IsPaste(s, "fresh"); }
        static bool IsSpread(ItemStack s) { return IsPaste(s, "spread"); }
        static bool IsRawSheet(ItemStack s)
        {
            return s != null && s.Collectible?.Code != null && s.Collectible.Code.Domain == "pisciculture" && s.Collectible.Code.Path == "noriraw";
        }
        static bool IsPanel(ItemStack s)
        {
            return s != null && s.Collectible?.Code != null && s.Collectible.Code.Domain == "pisciculture" && s.Collectible.Code.Path == "norimatpanel";
        }
        static bool IsStick(ItemStack s)
        {
            return s != null && s.Collectible?.Code != null && s.Collectible.Code.Domain == "game" && s.Collectible.Code.Path == "stick";
        }
        static bool IsTie(ItemStack s)
        {
            if (s == null || s.Collectible?.Code == null) return false;
            string p = s.Collectible.Code.Path;
            return p.StartsWith("papyrustops") || p.StartsWith("cattailtops");
        }

        ItemStack Unspread(ItemStack stack)
        {
            if (!IsSpread(stack)) return stack;
            Item fresh = Api.World.GetItem(new AssetLocation("pisciculture:algapaste-fresh"));
            if (fresh == null) return stack;
            ItemStack n = new ItemStack(fresh, stack.StackSize);
            return n;
        }

        // ---------------- interacao ----------------

        void Error(IPlayer byPlayer, string code, string msg)
        {
            if (Api.Side == EnumAppSide.Client)
            {
                (Api as ICoreClientAPI)?.TriggerIngameError(this, code, Lang.Get("pisciculture:" + msg));
            }
        }

        public bool OnInteract(IPlayer byPlayer, BlockSelection blockSel)
        {
            ItemSlot hand = byPlayer.InventoryManager.ActiveHotbarSlot;
            ItemStack held = hand?.Itemstack;
            bool server = Api.Side == EnumAppSide.Server;

            // --- Montagem ---
            if (stage < StageComplete)
            {
                if (stage < SticksNeeded)
                {
                    if (IsStick(held))
                    {
                        if (server) { stage++; hand.TakeOut(1); hand.MarkDirty(); AfterChange(); }
                        return true;
                    }
                    if (held != null || !byPlayer.Entity.Controls.ShiftKey) Error(byPlayer, "norirack-needstick", "norirack-needstick");
                    return true;
                }
                if (stage < StageFrontPanel)
                {
                    if (IsTie(held))
                    {
                        if (server)
                        {
                            if (tieCode == null) tieCode = held.Collectible.Code.ToString();
                            stage++; hand.TakeOut(1); hand.MarkDirty(); AfterChange();
                        }
                        return true;
                    }
                    Error(byPlayer, "norirack-needtie", "norirack-needtie");
                    return true;
                }
                // paineis
                if (IsPanel(held))
                {
                    if (server) { stage++; hand.TakeOut(1); hand.MarkDirty(); AfterChange(); }
                    return true;
                }
                // ja da para usar o painel da frente enquanto falta o de tras
            }

            if (stage >= StageFrontPanel)
            {
                if (byPlayer.Entity.Controls.ShiftKey && (held == null)) return TryTake(byPlayer, blockSel, true);
                if (IsFresh(held)) return TrySpread(byPlayer, blockSel, hand);
                if (held == null) return TryTake(byPlayer, blockSel, false);
                if (stage < StageComplete) Error(byPlayer, "norirack-needpanel", "norirack-needpanel");
            }
            return true;
        }

        bool SideHasPanel(int side) { return stage >= StageComplete; }

        const double LegAngle = 26.0;

        // converte o ponto clicado: front = face de cima (a que olha para o sol), linha e coluna na esteira
        void LocalHit(IPlayer byPlayer, BlockSelection sel, out bool front, out int row, out int col)
        {
            double x = sel.HitPosition.X - 0.5, z = sel.HitPosition.Z - 0.5, y = sel.HitPosition.Y;
            BlockSelection cur = byPlayer?.CurrentBlockSelection;
            if (cur != null && cur.Position != null) y += cur.Position.Y - Pos.Y;
            double th = RotateY * Math.PI / 180.0;
            double xl = x * Math.Cos(th) - z * Math.Sin(th);
            double zl = x * Math.Sin(th) + z * Math.Cos(th);
            double y16 = y * 16.0, z16 = (zl + 0.5) * 16.0;
            double sn = Math.Sin(LegAngle * Math.PI / 180.0), cs = Math.Cos(LegAngle * Math.PI / 180.0);
            double d = (y16 - 30.5) * sn + (z16 - 6.0) * cs;          // lado do plano da esteira
            double sl = -(y16 - 30.5) * cs + (z16 - 6.0) * sn;        // distancia ao longo da esteira, a partir do topo
            front = d >= 0;
            col = xl < 0 ? 0 : 1;
            row = sl < 11.8 ? 2 : (sl < 19.9 ? 1 : 0);
        }

        int SlotIndex(int row, int col) { return row * 2 + col; }

        bool TrySpread(IPlayer byPlayer, BlockSelection sel, ItemSlot hand)
        {
            bool front; int row, col;
            LocalHit(byPlayer, sel, out front, out row, out col);
            if (!SideHasPanel(0)) { Error(byPlayer, "norirack-needpanel", "norirack-needpanel"); return true; }
            if (!front) { Error(byPlayer, "norirack-wrongside", "norirack-wrongside"); return true; }
            int pick = -1;
            int first = SlotIndex(row, col);
            if (inv[first].Empty) pick = first;
            else for (int i = 0; i < SlotCount; i++) if (inv[i].Empty) { pick = i; break; }
            if (pick < 0) { Error(byPlayer, "norirack-full", "norirack-full"); return true; }
            if (Api.Side == EnumAppSide.Server)
            {
                Item spread = Api.World.GetItem(new AssetLocation("pisciculture:algapaste-spread"));
                if (spread == null) return true;
                hand.TakeOut(1);
                inv[pick].Itemstack = new ItemStack(spread, 1);
                hand.MarkDirty();
                inv[pick].MarkDirty();
                AfterChange();
                Api.World.PlaySoundAt(new AssetLocation("game:sounds/block/cloth"), Pos.X + 0.5, Pos.Y + 0.5, Pos.Z + 0.5, byPlayer);
            }
            return true;
        }

        bool TryTake(IPlayer byPlayer, BlockSelection sel, bool sneakPaste)
        {
            bool front; int row, col;
            LocalHit(byPlayer, sel, out front, out row, out col);
            int pick = -1;
            int[] order = new int[SlotCount];
            order[0] = SlotIndex(row, col);
            int k = 1;
            for (int i = 0; i < SlotCount; i++) if (i != order[0]) order[k++] = i;
            foreach (int idx in order)
            {
                ItemStack st = inv[idx].Itemstack;
                if (st == null) continue;
                if (IsRawSheet(st) || (sneakPaste && IsSpread(st))) { pick = idx; break; }
            }
            if (pick < 0)
            {
                bool anyWet = false;
                for (int i = 0; i < SlotCount; i++) if (IsSpread(inv[i].Itemstack)) anyWet = true;
                if (anyWet) Error(byPlayer, "norirack-stilldrying", "norirack-stilldrying");
                return true;
            }
            if (Api.Side == EnumAppSide.Server)
            {
                ItemStack st = inv[pick].TakeOut(1);
                st = Unspread(st);
                if (!byPlayer.InventoryManager.TryGiveItemstack(st, true))
                {
                    Api.World.SpawnItemEntity(st, Pos.ToVec3d().Add(0.5, 0.5, 0.5));
                }
                else if (st.StackSize > 0)
                {
                    Api.World.SpawnItemEntity(st, Pos.ToVec3d().Add(0.5, 0.5, 0.5));
                }
                inv[pick].MarkDirty();
                AfterChange();
            }
            return true;
        }

        /// <summary>Usado pelo graveto (Ctrl + botao direito): o primeiro graveto ja entra montado.</summary>
        public void AddFirstStick()
        {
            if (stage == 0) stage = 1;
            AfterChange();
        }

        void AfterChange()
        {
            MarkDirty(true);
            Api.World.BlockAccessor.MarkBlockDirty(Pos);
        }

        // ---------------- quebrar / devolver material ----------------

        public override void OnBlockBroken(IPlayer byPlayer = null)
        {
            if (Api.Side == EnumAppSide.Server)
            {
                for (int i = 0; i < SlotCount; i++)
                {
                    if (IsSpread(inv[i].Itemstack)) inv[i].Itemstack = Unspread(inv[i].Itemstack);
                }
                Vec3d at = Pos.ToVec3d().Add(0.5, 0.3, 0.5);
                int sticks = Math.Min(stage, SticksNeeded);
                if (sticks > 0) Api.World.SpawnItemEntity(new ItemStack(Api.World.GetItem(new AssetLocation("game:stick")), sticks), at);
                int ties = Math.Max(0, Math.Min(stage, StageFrontPanel) - SticksNeeded);
                if (ties > 0 && tieCode != null)
                {
                    Item tie = Api.World.GetItem(new AssetLocation(tieCode));
                    if (tie != null) Api.World.SpawnItemEntity(new ItemStack(tie, ties), at);
                }
                int panels = stage >= StageComplete ? 1 : 0;
                if (panels > 0)
                {
                    Item p = Api.World.GetItem(new AssetLocation("pisciculture:norimatpanel"));
                    if (p != null) Api.World.SpawnItemEntity(new ItemStack(p, panels), at);
                }
            }
            base.OnBlockBroken(byPlayer);
        }

        // ---------------- salvar ----------------

        public override void ToTreeAttributes(ITreeAttribute tree)
        {
            base.ToTreeAttributes(tree);
            tree.SetInt("stage", stage);
            if (tieCode != null) tree.SetString("tieCode", tieCode);
        }

        public override void FromTreeAttributes(ITreeAttribute tree, IWorldAccessor worldForResolving)
        {
            base.FromTreeAttributes(tree, worldForResolving);
            stage = tree.GetInt("stage", 0);
            tieCode = tree.GetString("tieCode", null);
            frameMeshStage = -1;
            RedrawAfterReceivingTreeAttributes(worldForResolving);
        }

        // ---------------- desenho ----------------

        protected override float[][] genTransformationMatrices()
        {
            float[][] mats = new float[SlotCount][];
            float rot = RotateY;
            float ang = (float)LegAngle;
            float sn = (float)Math.Sin(ang * Math.PI / 180.0), cs = (float)Math.Cos(ang * Math.PI / 180.0);
            float[] cx = new float[] { 5.55f, 10.45f };
            float[] along = new float[] { 23.95f, 15.85f, 7.75f };   // linha 0 = embaixo
            float off = 0.9f;                                         // para fora da face de cima
            for (int row = 0; row < 3; row++)
            {
                for (int col = 0; col < 2; col++)
                {
                    float y = 30.5f - along[row] * cs + off * sn;
                    float z = 6f + along[row] * sn + off * cs;
                    Matrixf m = new Matrixf();
                    m.Translate(0.5f, 0.5f, 0.5f).RotateYDeg(rot).Translate(-0.5f, -0.5f, -0.5f);
                    m.Translate(cx[col] / 16f, y / 16f, z / 16f);
                    m.RotateXDeg(-ang);
                    m.RotateXDeg(90);
                    m.Scale(0.5f, 0.5f, 0.5f);
                    m.Translate(-0.5f, -0.03f, -0.5f);
                    mats[row * 2 + col] = m.Values;
                }
            }
            return mats;
        }

        MeshData BuildFrameMesh()
        {
            ICoreClientAPI capi = Api as ICoreClientAPI;
            if (capi == null) return null;
            Shape shape = Shape.TryGet(capi, "pisciculture:shapes/block/norirack.json");
            if (shape == null) return null;
            List<string> sel = new List<string>();
            for (int i = 0; i < Math.Min(stage, StageElements.Length); i++) sel.AddRange(StageElements[i]);
            if (sel.Count == 0) return null;
            MeshData mesh;
            capi.Tesselator.TesselateShape(Block, shape, out mesh, new Vec3f(0, RotateY, 0), null, sel.ToArray());
            return mesh;
        }

        public override bool OnTesselation(ITerrainMeshPool mesher, ITesselatorAPI tessThreadTesselator)
        {
            if (frameMeshStage != stage)
            {
                frameMesh = BuildFrameMesh();
                frameMeshStage = stage;
            }
            if (frameMesh != null) mesher.AddMeshData(frameMesh);
            base.OnTesselation(mesher, tessThreadTesselator);
            // true = nao desenha o modelo padrao do bloco (os tocos do marcador); so as pecas ja montadas aparecem
            return true;
        }

        // ---------------- informacao ----------------

        public override void GetBlockInfo(IPlayer forPlayer, StringBuilder dsc)
        {
            if (stage < SticksNeeded)
                dsc.AppendLine(Lang.Get("pisciculture:norirack-info-sticks", stage, SticksNeeded));
            else if (stage < StageFrontPanel)
                dsc.AppendLine(Lang.Get("pisciculture:norirack-info-ties", stage - SticksNeeded, TiesNeeded));
            else if (stage < StageComplete)
                dsc.AppendLine(Lang.Get("pisciculture:norirack-info-panels", stage - StageFrontPanel, 1));

            if (stage >= StageFrontPanel)
            {
                dsc.AppendLine(Lang.Get("pisciculture:norirack-info-conditions", Lang.Get("pisciculture:norirack-cond-" + lastCondition)));
                for (int i = 0; i < SlotCount; i++)
                {
                    ItemStack st = inv[i].Itemstack;
                    if (!IsSpread(st)) continue;
                    TransitionState[] ts = st.Collectible.UpdateAndGetTransitionStates(Api.World, inv[i]);
                    if (ts == null) continue;
                    foreach (TransitionState t in ts)
                    {
                        if (t.Props.Type != EnumTransitionType.Dry) continue;
                        float total = t.FreshHours + t.TransitionHours;
                        float done = total <= 0 ? 0 : (t.TransitionedHours + (t.FreshHours - t.FreshHoursLeft)) / total;
                        // so conta a fase "transition" apos a fase fresca
                        float pct = GameMath.Clamp(done, 0f, 1f) * 100f;
                        dsc.AppendLine(Lang.Get("pisciculture:norirack-info-drying", Lang.Get("pisciculture:norirack-sheet", i + 1), (int)pct));
                    }
                }
            }
        }
    }

    /// <summary>
    /// Comportamento adicionado ao graveto do jogo: Ctrl + botao direito no chao comeca o cavalete de secagem de nori.
    /// </summary>
    public class CollectibleBehaviorNoriRackStarter : CollectibleBehavior
    {
        public CollectibleBehaviorNoriRackStarter(CollectibleObject collObj) : base(collObj) { }

        public override void OnHeldInteractStart(ItemSlot slot, EntityAgent byEntity, BlockSelection blockSel, EntitySelection entitySel, bool firstEvent, ref EnumHandHandling handHandling, ref EnumHandling handling)
        {
            if (blockSel == null || byEntity == null) return;
            if (!byEntity.Controls.CtrlKey || byEntity.Controls.ShiftKey) return;
            if (blockSel.Face != BlockFacing.UP) return;
            IPlayer player = (byEntity as EntityPlayer)?.Player;
            if (player == null) return;
            IWorldAccessor world = byEntity.World;

            Block rack = world.GetBlock(new AssetLocation("pisciculture:norirack-north"));
            if (rack == null) return;

            handHandling = EnumHandHandling.PreventDefault;
            handling = EnumHandling.PreventSubsequent;
            if (world.Side != EnumAppSide.Server) return;

            BlockSelection sel = blockSel.Clone();
            sel.Position = blockSel.Position.AddCopy(blockSel.Face);
            sel.DidOffset = true;
            string failure = "";
            ItemStack stack = new ItemStack(rack);
            if (!rack.TryPlaceBlock(world, player, stack, sel, ref failure))
            {
                (player as IServerPlayer)?.SendIngameError(failure ?? "cannotplace", Lang.Get("pisciculture:norirack-cannotplace"));
                return;
            }
            BlockEntityNoriRack be = world.BlockAccessor.GetBlockEntity(sel.Position) as BlockEntityNoriRack;
            if (be != null) be.AddFirstStick();
            if (player.WorldData.CurrentGameMode != EnumGameMode.Creative) slot.TakeOut(1);
            slot.MarkDirty();
            world.PlaySoundAt(new AssetLocation("game:sounds/block/loosestick"), sel.Position.X + 0.5, sel.Position.Y + 0.5, sel.Position.Z + 0.5, player);
        }
    }
}
