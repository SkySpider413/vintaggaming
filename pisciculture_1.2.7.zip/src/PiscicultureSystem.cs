using System;
using System.Collections.Generic;
using System.Text;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.Config;
using Vintagestory.API.Datastructures;
using Vintagestory.API.MathTools;
using Vintagestory.API.Server;
using Vintagestory.GameContent;

namespace Pisciculture
{
    /// <summary>
    /// Sistema principal do mod: faz as trutas-arco-iris comerem comida solta na agua,
    /// procriarem, colocarem blocos de ova no fundo, e permite carregar os peixes em baldes.
    /// </summary>
    public class PiscicultureSystem : ModSystem
    {
        // ---- Ajustes (valores faceis de mudar) ----

        /// <summary>Especies de agua doce do jogo base que este mod cria (tipo-especie). Adulto: game:fish-freshwater-X-adult; alevino: pisciculture:fish-X-juvenile.</summary>
        public static readonly string[] SpeciesKeys = new string[] { "alewife-shad", "chub-river", "crappie-black", "crappie-white", "perch-european", "perch-yellow", "piranha-black", "piranha-red", "trout-brown", "trout-rainbow", "bass-largemouth", "bass-smallmouth", "carp-common", "carp-grass", "catfish-blue", "catfish-channel", "pickerel-chain", "salmon-coho", "tilapia-nile", "tilapia-red", "walleye-common", "pike-northern", "arapaima-arapaima", "arapaima-gigas", "sheatfish-black", "sheatfish-white" };
        static readonly HashSet<string> SpeciesSet = new HashSet<string>(SpeciesKeys);
        public const string DefaultSpecies = "trout-rainbow";

        /// <summary>Especie (ex.: "trout-rainbow") a partir de um codigo de entidade, ou null se nao for um peixe do mod.</summary>
        public static string SpeciesOfCode(AssetLocation code)
        {
            if (code == null) return null;
            string p = code.Path;
            string key = null;
            if (code.Domain == "game" && p.StartsWith("fish-freshwater-") && p.EndsWith("-adult"))
                key = p.Substring(16, p.Length - 16 - 6);
            else if (code.Domain == "pisciculture" && p.StartsWith("fish-") && p.EndsWith("-juvenile"))
                key = p.Substring(5, p.Length - 5 - 9);
            if (key == null || !SpeciesSet.Contains(key)) return null;
            return key;
        }

        /// <summary>Quantos peixes crus um peixe de criacao com peso normal rende (depende do tamanho da especie).</summary>
        public static int BaseMeatCount(string sp)
        {
            if (sp == null) return 2;
            if (sp.StartsWith("arapaima") || sp.StartsWith("sheatfish")) return 10;
            if (sp.StartsWith("pike")) return 6;
            if (sp.StartsWith("bass") || sp.StartsWith("carp") || sp.StartsWith("catfish") || sp.StartsWith("pickerel") || sp.StartsWith("salmon") || sp.StartsWith("tilapia") || sp.StartsWith("walleye")) return 3;
            return 2;
        }

        public static string SpeciesOf(Entity e)
        {
            return e == null ? null : SpeciesOfCode(e.Code);
        }

        /// <summary>Intervalo entre verificacoes do sistema, em milissegundos.</summary>
        public const int TickMs = 2000;

        // Busca e consumo de comida (tick rapido para o peixe nadar suavemente ate o alimento)
        public const int FeedTickMs = 100;
        public const double SeekRangeHor = 24.0;
        public const double SeekRangeVert = 12.0;
        public const float EatSeconds = 1.4f;
        public const double SurfaceMargin = 1.1;    // o peixe so sobe enquanto houver agua ate esta altura acima dele
        public const double SwimSpeed = 0.04;
        public const double DigestDays = 1.0;       // o peixe digere 1 porcao por dia do jogo (volta a ter fome)
        public const int MaxEatersPerItem = 3;      // no maximo 3 peixes por montinho de comida
        public const float GiveUpSeconds = 30f;     // desiste se nao alcancar a comida
        public const long GiveUpPauseMs = 20000;    // e fica um tempo sem procurar comida

        // Domesticacao (igual aos outros animais: o medo some aos poucos e acaba nesta geracao)
        public const int TameGeneration = 10;
        public const float HealthBonusPerGeneration = 0.5f; // pontos de vida base a mais por geracao

        /// <summary>Porcoes que a truta precisa comer para poder procriar.</summary>
        public const float PortionsToBreed = 3f;

        /// <summary>Maximo de porcoes que a truta guarda.</summary>
        public const float MaxPortions = 6f;

        /// <summary>Dias de espera entre uma desova e a proxima (minimo e maximo).</summary>
        public const double CooldownDaysMin = 3;
        public const double CooldownDaysMax = 6;

        /// <summary>Chance de desovar a cada verificacao, quando a truta esta pronta.</summary>
        public const double LayChancePerTick = 0.25;

        /// <summary>Outra truta precisa estar a esta distancia para haver procriacao.</summary>
        public const float MateRangeHor = 8f;
        public const float MateRangeVert = 4f;

        /// <summary>Eclosao real da truta-arco-iris: ~31 dias de um ano de 365 (a ~10 C).</summary>
        public const double RealIncubationDays = 31.0;
        public const double RealDaysPerYear = 365.0;

        /// <summary>Mesma proporcao do ano, mas no calendario do jogo (com 108 dias por ano da ~9,2 dias).</summary>
        public static double GetIncubationDays(IWorldAccessor world)
        {
            return RealIncubationDays / RealDaysPerYear * world.Calendar.DaysPerYear;
        }

        /// <summary>Maximo de trutas num raio de 16 blocos; acima disso as ovas esperam.</summary>
        public const int MaxTroutNearRoe = 12;

        /// <summary>Raio em volta de cada jogador onde o sistema procura trutas e comida.</summary>
        public const float ScanRangeHor = 48f;
        public const float ScanRangeVert = 32f;

        // ---- Chaves salvas na truta ----
        public const string KeyPortions = "pisciculturePortions";
        public const string KeyCooldown = "piscicultureCooldownUntil";
        public const string KeyGravidUntil = "pisciculGravidUntil";   // dia do jogo em que as ovas ficam prontas
        public const string KeyGravidStart = "pisciculGravidStart";

        /// <summary>Dias do jogo que as ovas ficam dentro do peixe antes de serem soltas.</summary>
        public const double GestationDaysMin = 1;
        public const double GestationDaysMax = 2;

        // ---- Chaves salvas no balde ----
        public const string KeyBucketFish = "piscicultureFish";
        public const string KeyBucketCode = "piscicultureBucketCode";

        ICoreServerAPI sapi;

        static double goodHuntingMeat = -1;

        /// <summary>
        /// Compatibilidade com o Good Hunting Forked: aplica o multiplicador de carne dele (config goodhuntingforked.json)
        /// na carne dos peixes de criacao. Sem o mod, ou com ele desligado, vale 1.
        /// </summary>
        public static double GoodHuntingMeatFactor(ICoreAPI api)
        {
            if (goodHuntingMeat >= 0) return goodHuntingMeat;
            double factor = 1.0;
            try
            {
                if (api != null && api.ModLoader.IsModEnabled("goodhuntingforked"))
                {
                    string file = System.IO.Path.Combine(api.GetOrCreateDataPath("ModConfig"), "goodhuntingforked.json");
                    if (System.IO.File.Exists(file))
                    {
                        string text = System.IO.File.ReadAllText(file);
                        string en = RawJsonValue(text, "enabled");
                        bool off = en != null && en.Equals("false", StringComparison.OrdinalIgnoreCase);
                        if (!off) factor = ReadGoodHuntingValue(text, "allMultiplier") * ReadGoodHuntingValue(text, "meatMultiplier");
                    }
                }
            }
            catch (Exception) { factor = 1.0; }
            if (factor < 0) factor = 1.0;
            goodHuntingMeat = factor;
            return factor;
        }

        /// <summary>Valor cru (sem aspas) de uma chave simples num JSON de configuracao; null se nao existir.</summary>
        static string RawJsonValue(string text, string key)
        {
            int idx = text.IndexOf("\"" + key + "\"", StringComparison.OrdinalIgnoreCase);
            if (idx < 0) return null;
            int colon = text.IndexOf(':', idx);
            if (colon < 0) return null;
            int end = colon + 1;
            while (end < text.Length && text[end] != ',' && text[end] != '}' && text[end] != '\n' && text[end] != '\r') end++;
            return text.Substring(colon + 1, end - colon - 1).Trim().Trim('"');
        }

        static double ReadGoodHuntingValue(string text, string key)
        {
            string raw = RawJsonValue(text, key);
            double v;
            if (raw != null && double.TryParse(raw, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out v)) return v;
            return 1.0;
        }

        public override void Start(ICoreAPI api)
        {
            base.Start(api);
            api.RegisterEntity("PiscicultureFish", typeof(EntityPiscicultureFish));
            api.RegisterEntityBehaviorClass("piscicultureinfo", typeof(EntityBehaviorPiscicultureInfo));
            api.RegisterEntityBehaviorClass("piscicultureharvestable", typeof(EntityBehaviorPiscicultureHarvestable));
            api.RegisterCollectibleBehaviorClass("PiscicultureHandbook", typeof(CollectibleBehaviorPiscicultureHandbook));
            api.RegisterItemClass("PiscicultureCreature", typeof(ItemPiscicultureCreature));
            api.RegisterBlockEntityClass("PiscicultureRoe", typeof(BlockEntityTroutRoe));
            api.RegisterBlockClass("BlockFishBucket", typeof(BlockFishBucket));
            api.RegisterBlockClass("BlockFishRoe", typeof(BlockFishRoe));
            api.RegisterBlockEntityClass("PiscicultureFishBucket", typeof(BlockEntityFishBucket));
            api.RegisterCollectibleBehaviorClass("PiscicultureNoriRackStarter", typeof(CollectibleBehaviorNoriRackStarter));
            api.RegisterBlockClass("BlockNoriRack", typeof(BlockNoriRack));
            api.RegisterBlockEntityClass("PiscicultureNoriRack", typeof(BlockEntityNoriRack));
        }

        ICoreClientAPI capi;
        long handbookListenerId;

        public override void StartClientSide(ICoreClientAPI api)
        {
            base.StartClientSide(api);
            capi = api;
            // O manual cria o seu proprio comportamento nos itens; troca-o pelo nosso nos peixes (sem fundo nos icones).
            handbookListenerId = api.Event.RegisterGameTickListener(SwapHandbookBehavior, 1000);
        }

        void SwapHandbookBehavior(float dt)
        {
            bool found = false;
            bool anyFishItem = false;
            foreach (Item obj in capi.World.Items)
            {
                if (obj == null || obj.Code == null || obj.Code.Domain != "game" || !obj.Code.Path.StartsWith("creature-fish-freshwater-")) continue;
                anyFishItem = true;
                // Se outro mod (ex.: Ithania) trocou a classe do item, mantemos o comportamento original do manual.
                if (!(obj is ItemPiscicultureCreature)) continue;
                CollectibleBehavior[] list = obj.CollectibleBehaviors;
                if (list == null) continue;
                for (int i = 0; i < list.Length; i++)
                {
                    if (list[i] is CollectibleBehaviorPiscicultureHandbook) { found = true; break; }
                    if (list[i].GetType() != typeof(CollectibleBehaviorHandbookTextAndExtraInfo)) continue;
                    CollectibleBehaviorPiscicultureHandbook mine = new CollectibleBehaviorPiscicultureHandbook(obj);
                    mine.OnLoaded(capi);
                    list[i] = mine;
                    found = true;
                    break;
                }
            }
            if (found || anyFishItem) capi.Event.UnregisterGameTickListener(handbookListenerId);
        }

        public override void StartServerSide(ICoreServerAPI api)
        {
            base.StartServerSide(api);
            sapi = api;

            api.Event.RegisterGameTickListener(OnFarmTick, TickMs);
            api.Event.RegisterGameTickListener(OnFeedTick, FeedTickMs);
            api.Event.HandInteract += OnHandInteract;

            api.ChatCommands.Create("pisciculture")
                .WithDescription(Lang.Get("pisciculture:cmd-desc"))
                .RequiresPrivilege(Privilege.chat)
                .RequiresPlayer()
                .HandleWith(OnCmdStatus);
        }

        // ------------------------------------------------------------------
        // Identificacao
        // ------------------------------------------------------------------

        public static bool IsTrout(Entity e)
        {
            return e != null && e.Code != null && e.Code.Domain == "game" && SpeciesOfCode(e.Code) != null;
        }

        public static bool IsJuvenile(Entity e)
        {
            return e != null && e.Code != null && e.Code.Domain == "pisciculture" && SpeciesOfCode(e.Code) != null;
        }

        public static bool IsAnyTrout(Entity e)
        {
            return IsTrout(e) || IsJuvenile(e);
        }

        public enum Diet { Carnivore, Herbivore, Omnivore }

        /// <summary>Dieta de cada especie, como na vida real. Carnivoros: so carne; herbivoros: so graos e vegetais; onivoros: os dois.</summary>
        static readonly Dictionary<string, Diet> Diets = new Dictionary<string, Diet>
        {
            { "alewife-shad", Diet.Carnivore }, { "chub-river", Diet.Carnivore },
            { "crappie-black", Diet.Carnivore }, { "crappie-white", Diet.Carnivore },
            { "perch-european", Diet.Carnivore }, { "perch-yellow", Diet.Carnivore },
            { "piranha-black", Diet.Carnivore }, { "piranha-red", Diet.Carnivore },
            { "trout-brown", Diet.Carnivore }, { "trout-rainbow", Diet.Carnivore },
            { "bass-largemouth", Diet.Carnivore }, { "bass-smallmouth", Diet.Carnivore },
            { "pickerel-chain", Diet.Carnivore }, { "salmon-coho", Diet.Carnivore },
            { "walleye-common", Diet.Carnivore }, { "pike-northern", Diet.Carnivore },
            { "arapaima-arapaima", Diet.Carnivore }, { "arapaima-gigas", Diet.Carnivore },
            { "catfish-blue", Diet.Omnivore }, { "catfish-channel", Diet.Omnivore },
            { "sheatfish-black", Diet.Omnivore }, { "sheatfish-white", Diet.Omnivore },
            { "tilapia-nile", Diet.Omnivore }, { "tilapia-red", Diet.Omnivore },
            { "carp-common", Diet.Herbivore }, { "carp-grass", Diet.Herbivore }
        };

        /// <summary>Tipos de alimento natural (cru, sem preparo) que o mod reconhece.</summary>
        [Flags]
        public enum Food
        {
            None = 0,
            Worm = 1,      // minhoca, larvas e cupins
            Fish = 2,      // peixe cru (inteiro, filé ou pedaços)
            Meat = 4,      // carne vermelha, de ave e de caça crua
            Egg = 8,       // ovo cru
            Rot = 16,      // carne podre
            Grain = 32,    // espelta, arroz, linhaça, centeio, amaranto, girassol
            Legume = 64,   // soja e amendoim
            Veg = 128,     // legumes, vegetais e raízes silvestres
            Fruit = 256    // frutas
        }

        const Food Animal = Food.Worm | Food.Fish | Food.Meat | Food.Egg | Food.Rot;
        const Food Plant = Food.Grain | Food.Legume | Food.Veg | Food.Fruit;

        /// <summary>O que cada especie aceita, conforme a dieta real dela.</summary>
        static readonly Dictionary<string, Food> SpeciesFoods = new Dictionary<string, Food>
        {
            // Carnivoros
            { "alewife-shad", Food.Worm },
            { "chub-river", Food.Worm | Food.Fish },
            { "crappie-black", Food.Worm | Food.Fish },
            { "crappie-white", Food.Worm | Food.Fish },
            { "perch-european", Food.Worm | Food.Fish },
            { "perch-yellow", Food.Worm | Food.Fish | Food.Egg },
            { "piranha-black", Food.Fish | Food.Meat | Food.Rot },
            { "piranha-red", Food.Fish | Food.Worm | Food.Meat | Food.Rot },
            { "trout-brown", Food.Worm | Food.Fish },
            { "trout-rainbow", Food.Worm | Food.Fish },
            { "bass-largemouth", Food.Fish | Food.Worm | Food.Meat },
            { "bass-smallmouth", Food.Worm | Food.Fish },
            { "pickerel-chain", Food.Fish },
            { "salmon-coho", Food.Fish | Food.Worm },
            { "walleye-common", Food.Fish | Food.Worm },
            { "pike-northern", Food.Fish | Food.Meat },
            { "arapaima-arapaima", Food.Fish },
            { "arapaima-gigas", Food.Fish },
            // Onivoros
            { "catfish-blue", Food.Fish | Food.Meat | Food.Worm | Food.Grain | Food.Legume | Food.Veg },
            { "catfish-channel", Food.Worm | Food.Fish | Food.Rot | Food.Grain | Food.Legume | Food.Veg },
            { "sheatfish-black", Food.Worm | Food.Fish | Food.Rot | Food.Grain | Food.Legume | Food.Veg },
            { "sheatfish-white", Food.Worm | Food.Fish | Food.Rot | Food.Grain | Food.Legume | Food.Veg },
            { "tilapia-nile", Food.Worm | Food.Grain | Food.Legume | Food.Veg },
            { "tilapia-red", Food.Worm | Food.Grain | Food.Legume | Food.Veg | Food.Fruit },
            // Herbivoros (a carpa-comum tambem come vermes e insetos)
            { "carp-common", Food.Worm | Food.Grain | Food.Legume | Food.Veg | Food.Fruit },
            { "carp-grass", Food.Grain | Food.Legume | Food.Veg | Food.Fruit }
        };

        /// <summary>Tipos de alimento de um item (None se nao for comida de peixe). So alimentos naturais e crus.</summary>
        static Food FoodKindsOf(ItemStack stack)
        {
            if (stack == null || stack.Collectible == null) return Food.None;
            AssetLocation code = stack.Collectible.Code;
            if (code == null) return Food.None;
            string path = code.Path;

            if (code.Domain == "game")
            {
                switch (path)
                {
                    case "redmeat-raw": case "poultry-raw": case "bushmeat-raw": return Food.Meat;
                    case "fish-raw": return Food.Fish;
                    case "egg-chicken-raw": return Food.Egg;
                    case "rot": return Food.Rot;
                    case "cattailroot": case "papyrusroot": case "tuleroot": return Food.Veg;
                }
                if (path.StartsWith("fishraw-")) return Food.Fish;
                if (path.StartsWith("fishchunk-")) return path.Contains("cooked") ? Food.None : Food.Fish;
                if (path.StartsWith("insect-")) return Food.Worm;
                if (path.StartsWith("grain-")) return Food.Grain;
                if (path.StartsWith("legume-")) return Food.Legume;
                if (path.StartsWith("fruit-")) return Food.Fruit;
                if (path.StartsWith("vegetable-")) return path.StartsWith("vegetable-cooked") ? Food.None : Food.Veg;
            }

            // Compatibilidade: Expanded Foods (so ingredientes crus e naturais)
            if (code.Domain == "expandedfoods")
            {
                if (path.StartsWith("fishnugget-")) return (path.EndsWith("-raw") || path.EndsWith("-smashed")) ? Food.Fish : Food.None;
                if (path.StartsWith("meatnugget-")) return (path.EndsWith("-raw") || path.EndsWith("-smashed")) ? Food.Meat : Food.None;
                if (path.StartsWith("choppedvegetable-")) return path.Contains("pickled") ? Food.None : Food.Veg;
                if (path == "driedseaweed-mash" || path == "driedseaweed-washed") return Food.Veg;
            }

            // Compatibilidade: Primitive Survival (ovas cruas de peixe)
            if (code.Domain == "primitivesurvival" && path.StartsWith("fisheggs-raw")) return Food.Egg;

            // Minhocas vivas de outros mods (Ithania Expanded Fishing, Primitive Survival etc.) marcam o item com baitTag
            string tag = stack.Collectible.Attributes?["baitTag"].AsString();
            if (tag == "bait-worm" || tag == "bait-nightcrawler" || tag == "bait-r3dworm" || tag == "bait-seaworm" || tag == "bait-scented") return Food.Worm;
            return Food.None;
        }

        /// <summary>Este peixe aceita este item?</summary>
        static bool Accepts(Entity fish, ItemStack stack)
        {
            string sp = SpeciesOf(fish);
            Food mask;
            if (sp == null || !SpeciesFoods.TryGetValue(sp, out mask)) mask = Animal | Plant;
            return (FoodKindsOf(stack) & mask) != Food.None;
        }

        public static Diet DietOf(string species)
        {
            Diet d;
            return species != null && Diets.TryGetValue(species, out d) ? d : Diet.Omnivore;
        }

        /// <summary>Dieta da especie, traduzida, para dicas e mensagens.</summary>
        public static string DietText(string species, string langCode = null)
        {
            string key = "pisciculture:diet-" + DietOf(species).ToString().ToLowerInvariant();
            return langCode == null ? Lang.Get(key) : Lang.GetL(langCode, key);
        }

        static float GetPortions(Entity fish)
        {
            return fish.WatchedAttributes.GetFloat(KeyPortions, 0f);
        }

        static void SetPortions(Entity fish, float value)
        {
            fish.WatchedAttributes.SetFloat(KeyPortions, value);
        }

        static double GetCooldown(Entity fish)
        {
            return fish.WatchedAttributes.GetDouble(KeyCooldown, 0.0);
        }

        static void SetCooldown(Entity fish, double value)
        {
            fish.WatchedAttributes.SetDouble(KeyCooldown, value);
        }

        // ------------------------------------------------------------------
        // Alimentacao e procriacao
        // ------------------------------------------------------------------

        void OnFarmTick(float dt)
        {
            if (sapi == null || sapi.World == null || sapi.World.Calendar == null) return;

            List<Entity> trout = new List<Entity>();
            double now = sapi.World.Calendar.TotalDays;

            // So cuidamos do que esta perto de algum jogador (peixes longe de todos ficam parados no mundo).
            HashSet<long> seen = new HashSet<long>();
            IPlayer[] players = sapi.World.AllOnlinePlayers;
            for (int p = 0; p < players.Length; p++)
            {
                IPlayer plr = players[p];
                if (plr == null || plr.Entity == null) continue;

                Entity[] around = sapi.World.GetEntitiesAround(plr.Entity.Pos.XYZ, ScanRangeHor, ScanRangeVert, ent => ent.Alive && IsAnyTrout(ent));
                for (int k = 0; k < around.Length; k++)
                {
                    Entity e = around[k];
                    if (e == null || !seen.Add(e.EntityId)) continue;

                    if (IsTrout(e))
                    {
                        trout.Add(e);
                        MakeFarmFish(e);
                    }
                    else if (IsJuvenile(e))
                    {
                        MakeFarmFish(e);
                    }
                }
            }

            // Limpeza periodica: evita que os registros de peixes ja sumidos cresçam para sempre.
            if (recentLay.Count > 0 || hookedManagers.Count > 0)
            {
                long nowMsClean = sapi.World.ElapsedMilliseconds;
                List<long> gone = null;
                foreach (KeyValuePair<long, long> kv in recentLay)
                    if (nowMsClean - kv.Value > 60000) { if (gone == null) gone = new List<long>(); gone.Add(kv.Key); }
                if (gone != null) for (int i = 0; i < gone.Count; i++) recentLay.Remove(gone[i]);
                List<long> dead = null;
                foreach (long id in hookedManagers.Keys)
                {
                    Entity ent = sapi.World.GetEntityById(id);
                    if (ent == null || !ent.Alive) { if (dead == null) dead = new List<long>(); dead.Add(id); }
                }
                if (dead != null) for (int i = 0; i < dead.Count; i++) hookedManagers.Remove(dead[i]);
            }

            if (trout.Count == 0) return;

            // Digestao: a cada DigestDays (dias do jogo) o peixe perde 1 porcao e volta a ter fome.
            double nowDigest = now;
            for (int i = 0; i < trout.Count; i++)
            {
                Entity f = trout[i];
                double last = f.WatchedAttributes.GetDouble("pisciculDigestAt", -1.0);
                if (last < 0 || last > nowDigest) { f.WatchedAttributes.SetDouble("pisciculDigestAt", nowDigest); continue; }
                if (nowDigest - last >= DigestDays)
                {
                    f.WatchedAttributes.SetDouble("pisciculDigestAt", nowDigest);
                    // Condicao fisica (peso): quem comeu engorda aos poucos; quem ficou sem comer emagrece. Define a carne ao abater.
                    bool wasFed = GetPortions(f) > 0f;
                    float weight = f.WatchedAttributes.GetFloat("animalWeight", 0.75f);
                    weight = wasFed ? Math.Min(1f, weight + 0.06f) : Math.Max(0.5f, weight - 0.04f);
                    f.WatchedAttributes.SetFloat("animalWeight", weight);
                    if (wasFed) SetPortions(f, Math.Max(0f, GetPortions(f) - 1f));
                }
            }

            // Procriacao: 1) peixe alimentado, sem descanso e com parceiro por perto fica com ovas;
            // 2) depois da gestacao ele solta as ovas e o parceiro as fertiliza.
            for (int i = 0; i < trout.Count; i++)
            {
                Entity fish = trout[i];
                if (!fish.Alive) continue;
                if (visitBusy.Contains(fish.EntityId)) continue;   // peixe que esta fertilizando uma ova nao desova ao mesmo tempo

                double gravidUntil = fish.WatchedAttributes.GetDouble(KeyGravidUntil, 0.0);
                if (gravidUntil > 0)
                {
                    if (gravidUntil > now) continue;               // ainda gestando
                    if (!HasMate(fish, trout)) continue;           // espera um parceiro chegar

                    Entity visitor = PickMate(fish, trout);
                    if (visitor == null) continue;                 // sem parceiro livre para fertilizar: espera
                    BlockPos laidAt;
                    if (TryLayRoe(fish, out laidAt))
                    {
                        fish.WatchedAttributes.SetDouble(KeyGravidUntil, 0.0);
                        recentLay[fish.EntityId] = sapi.World.ElapsedMilliseconds;
                        StartMateVisit(visitor, laidAt);
                        double wait = CooldownDaysMin + sapi.World.Rand.NextDouble() * (CooldownDaysMax - CooldownDaysMin);
                        SetCooldown(fish, now + wait);
                        SetCooldown(visitor, now + wait);   // desovar e fertilizar e um evento so: o parceiro tambem descansa
                        sapi.Logger.Debug("[pisciculture] Peixe desovou em " + fish.Pos.AsBlockPos);
                    }
                    continue;
                }

                if (GetPortions(fish) < PortionsToBreed) continue;
                if (GetCooldown(fish) > now) continue;
                if (sapi.World.Rand.NextDouble() > LayChancePerTick) continue;
                if (!HasMate(fish, trout)) continue;

                SetPortions(fish, GetPortions(fish) - PortionsToBreed);
                double gest = GestationDaysMin + sapi.World.Rand.NextDouble() * (GestationDaysMax - GestationDaysMin);
                fish.WatchedAttributes.SetDouble(KeyGravidStart, now);
                fish.WatchedAttributes.SetDouble(KeyGravidUntil, now + gest);
            }
        }


        // ------------------------------------------------------------------
        // Peixe nadando ate a comida e comendo
        // ------------------------------------------------------------------

        // ------------------------------------------------------------------
        // Fertilizacao: um parceiro da mesma especie visita a ova e nada em volta dela
        // ------------------------------------------------------------------

        class MateVisit
        {
            public long MateId;
            public Vec3d Center;
            public float Total;
            public float Orbit;
            public bool Arrived;
        }

        const float VisitOrbitSeconds = 3f;
        const float VisitTimeoutSeconds = 15f;
        readonly List<MateVisit> visits = new List<MateVisit>();
        readonly HashSet<long> visitBusy = new HashSet<long>();
        readonly Dictionary<long, long> recentLay = new Dictionary<long, long>();   // quem desovou ha pouco nao serve de parceiro

        Entity PickMate(Entity layer, List<Entity> all)
        {
            string sp = SpeciesOf(layer);
            Entity best = null;
            double bestD = double.MaxValue;
            for (int i = 0; i < all.Count; i++)
            {
                Entity o = all[i];
                if (o.EntityId == layer.EntityId || !o.Alive || SpeciesOf(o) != sp || visitBusy.Contains(o.EntityId)) continue;
                long layMs;
                if (recentLay.TryGetValue(o.EntityId, out layMs) && sapi.World.ElapsedMilliseconds - layMs < 30000) continue;
                double dx = o.Pos.X - layer.Pos.X, dy = o.Pos.Y - layer.Pos.Y, dz = o.Pos.Z - layer.Pos.Z;
                if (Math.Abs(dy) > MateRangeVert || dx * dx + dz * dz > MateRangeHor * MateRangeHor) continue;
                double d = dx * dx + dy * dy + dz * dz;
                if (d < bestD) { bestD = d; best = o; }
            }
            return best;
        }

        void StartMateVisit(Entity best, BlockPos roePos)
        {
            MateVisit v = new MateVisit();
            v.MateId = best.EntityId;
            v.Center = new Vec3d(roePos.X + 0.5, roePos.Y + 0.4, roePos.Z + 0.5);
            visits.Add(v);
            visitBusy.Add(best.EntityId);
        }

        void EndVisit(Entity mate, MateVisit v)
        {
            visitBusy.Remove(v.MateId);
            if (mate != null) mate.Pos.Motion.Set(0, 0, 0);
            // nuvem leitosa ao fim da fertilizacao
            SpawnMilt(v.Center, 14f);
        }

        void SpawnMilt(Vec3d c, float quantity)
        {
            sapi.World.SpawnParticles(
                quantity,
                ColorUtil.ToRgba(190, 250, 250, 235),
                new Vec3d(c.X - 0.25, c.Y - 0.05, c.Z - 0.25),
                new Vec3d(c.X + 0.25, c.Y + 0.25, c.Z + 0.25),
                new Vec3f(-0.05f, 0.02f, -0.05f),
                new Vec3f(0.05f, 0.12f, 0.05f),
                1.6f,
                0f,
                0.3f,
                EnumParticleModel.Quad);
        }

        void ProcessVisits(float dt)
        {
            for (int i = visits.Count - 1; i >= 0; i--)
            {
                MateVisit v = visits[i];
                Entity mate = sapi.World.GetEntityById(v.MateId);
                v.Total += dt;

                if (mate == null || !mate.Alive || v.Total > VisitTimeoutSeconds)
                {
                    EndVisit(mate, v);
                    visits.RemoveAt(i);
                    continue;
                }

                EntityBehaviorTaskAI ai = mate.GetBehavior<EntityBehaviorTaskAI>();
                if (ai != null && ai.TaskManager != null)
                {
                    EnsureHook(mate, ai.TaskManager);
                    if (visitBusy.Contains(v.MateId)) ai.TaskManager.StopTasks();
                }

                double tx = v.Center.X, tz = v.Center.Z;
                double ty = v.Center.Y + 0.1;
                double dxc = v.Center.X - mate.Pos.X, dzc = v.Center.Z - mate.Pos.Z;
                double hor = Math.Sqrt(dxc * dxc + dzc * dzc);

                if (!v.Arrived && hor < 0.8) v.Arrived = true;

                if (v.Arrived)
                {
                    v.Orbit += dt;
                    double ang = v.Orbit * 2.4;
                    tx += Math.Cos(ang) * 0.45;
                    tz += Math.Sin(ang) * 0.45;
                    if (sapi.World.Rand.NextDouble() < 0.5) SpawnMilt(v.Center, 2f);
                }

                double mx = tx - mate.Pos.X, my = ty - mate.Pos.Y, mz = tz - mate.Pos.Z;
                double dist = Math.Sqrt(mx * mx + my * my + mz * mz);
                if (dist < 0.01) dist = 0.01;
                double speed = Math.Min(SwimSpeed * 1.2, dist * 0.6 + 0.005);
                mate.Pos.Motion.Set(mx / dist * speed, my / dist * speed, mz / dist * speed);
                if (Math.Abs(mx) + Math.Abs(mz) > 0.01) mate.Pos.Yaw = (float)Math.Atan2(mx, mz);

                if (v.Arrived && v.Orbit >= VisitOrbitSeconds)
                {
                    EndVisit(mate, v);
                    visits.RemoveAt(i);
                }
            }
        }

        class FeedState
        {
            public long TargetId = -1;
            public float EatTime;
            public float ChaseTime;
            public bool Eating;
            public long PausedUntilMs;
        }

        readonly Dictionary<long, FeedState> feedStates = new Dictionary<long, FeedState>();
        readonly AnimationMetaData eatAnim = new AnimationMetaData() { Code = "eat2", Animation = "rising-eat", AnimationSpeed = 0.6f };
        bool eatAnimInit;
        long diagMs;
        int idleFeedTicks;

        // Inclinacao do peixe (rad) ao comer comida que afundou: foca o focinho para baixo, em direcao a comida no fundo.
        // Se o peixe aparecer inclinado para cima em vez de para baixo, troque o sinal desta constante.
        const float FeedPitchSign = 1f;
        readonly Dictionary<long, float> tilted = new Dictionary<long, float>();

        /// <summary>Quanto o peixe consegue baixar o focinho: peixes pequenos inclinam bastante, os grandes pouco.</summary>
        static float MaxTilt(Entity fish)
        {
            float size = Math.Max(fish.SelectionBox.XSize, fish.SelectionBox.ZSize);
            float t = (size - 0.4f) / 1.0f;
            if (t < 0f) t = 0f; else if (t > 1f) t = 1f;
            return 0.65f - 0.4f * t;   // de ~37 graus (pequeno) a ~14 graus (grande)
        }

        /// <summary>Aproxima suavemente a inclinacao do peixe da meta (0 = posicao normal).</summary>
        void EaseTilt(Entity fish, float goal)
        {
            float cur;
            tilted.TryGetValue(fish.EntityId, out cur);
            cur += (goal - cur) * 0.2f;
            if (goal == 0f && Math.Abs(cur) < 0.02f)
            {
                tilted.Remove(fish.EntityId);
                fish.Pos.Pitch = 0f;
                return;
            }
            tilted[fish.EntityId] = cur;
            fish.Pos.Pitch = cur;
        }

        /// <summary>Peixes que ainda estao inclinados voltam devagar a posicao normal (os que nao pediram inclinacao neste ciclo).</summary>
        void RelaxTilted(HashSet<long> keep)
        {
            if (tilted.Count == 0) return;
            List<long> ids = new List<long>(tilted.Keys);
            for (int i = 0; i < ids.Count; i++)
            {
                if (keep != null && keep.Contains(ids[i])) continue;
                Entity f = sapi.World.GetEntityById(ids[i]);
                if (f == null || !f.Alive) { tilted.Remove(ids[i]); continue; }
                EaseTilt(f, 0f);
            }
        }

        // Peixes "ocupados" comendo: as tarefas normais de IA (vagar, fugir...) ficam bloqueadas para eles.
        readonly HashSet<long> busyFish = new HashSet<long>();
        readonly Dictionary<long, AiTaskManager> hookedManagers = new Dictionary<long, AiTaskManager>();

        void EnsureHook(Entity fish, AiTaskManager tm)
        {
            AiTaskManager existing;
            if (hookedManagers.TryGetValue(fish.EntityId, out existing) && existing == tm) return;
            hookedManagers[fish.EntityId] = tm;
            long id = fish.EntityId;
            tm.OnShouldExecuteTask += (IAiTask task) => !busyFish.Contains(id) && !visitBusy.Contains(id);
        }

        /// <summary>Ha agua a esta altura acima do peixe? (impede que ele suba ate a superficie e saia da agua)</summary>
        bool WaterAbove(Entity e, double dy)
        {
            BlockPos above = new BlockPos((int)Math.Floor(e.Pos.X), (int)Math.Floor(e.Pos.Y + dy), (int)Math.Floor(e.Pos.Z), e.Pos.Dimension);
            return sapi.World.BlockAccessor.GetBlock(above, BlockLayersAccess.Fluid).IsLiquid();
        }

        /// <summary>Comida parada no fundo (bloco solido logo abaixo), como as minhocas vivas, que afundam.</summary>
        bool OnBottom(Entity e)
        {
            BlockPos below = new BlockPos((int)Math.Floor(e.Pos.X), (int)Math.Floor(e.Pos.Y - 0.12), (int)Math.Floor(e.Pos.Z), e.Pos.Dimension);
            Block b = sapi.World.BlockAccessor.GetBlock(below);
            return b != null && b.Id != 0 && b.SideSolid[BlockFacing.UP.Index];
        }

        bool InWater(Entity e)
        {
            IBlockAccessor ba = sapi.World.BlockAccessor;
            if (ba.GetBlock(e.Pos.AsBlockPos, BlockLayersAccess.Fluid).IsLiquid()) return true;
            // comida flutuando na superficie fica um pouco acima do bloco de agua
            BlockPos below = new BlockPos((int)Math.Floor(e.Pos.X), (int)Math.Floor(e.Pos.Y - 0.35), (int)Math.Floor(e.Pos.Z), e.Pos.Dimension);
            return ba.GetBlock(below, BlockLayersAccess.Fluid).IsLiquid();
        }

        /// <summary>Filtro do tick de alimentacao: peixes adultos vivos e comida solta (graos, carne, iscas).</summary>
        static bool IsFeedTickRelevant(Entity e)
        {
            if (!e.Alive) return false;
            if (IsTrout(e)) return true;
            EntityItem ei = e as EntityItem;
            return ei != null && ei.Itemstack != null && FoodKindsOf(ei.Itemstack) != Food.None;
        }

        void OnFeedTick(float dt)
        {
            try { OnFeedTickInner(dt); }
            catch (Exception ex) { sapi.Logger.Error("[pisciculture] erro na alimentacao: " + ex); }
        }

        void OnFeedTickInner(float dt)
        {
            if (sapi == null || sapi.World == null) return;
            if (!eatAnimInit) { eatAnim.Init(); eatAnimInit = true; }
            if (visits.Count > 0) ProcessVisits(dt);

            // Sem comida na agua no ultimo exame: examina so a cada 5 ciclos (0,5 s) para poupar o servidor.
            if (idleFeedTicks > 0 && visits.Count == 0 && busyFish.Count == 0 && tilted.Count == 0) { idleFeedTicks--; return; }

            List<Entity> fishes = new List<Entity>();
            Dictionary<long, EntityItem> foods = new Dictionary<long, EntityItem>();
            HashSet<long> seen = new HashSet<long>();
            int foodsDry = 0;

            IPlayer[] players = sapi.World.AllOnlinePlayers;
            for (int p = 0; p < players.Length; p++)
            {
                IPlayer plr = players[p];
                if (plr == null || plr.Entity == null) continue;

                Entity[] around = sapi.World.GetEntitiesAround(plr.Entity.Pos.XYZ, 32f, 16f, IsFeedTickRelevant);
                for (int k = 0; k < around.Length; k++)
                {
                    Entity e = around[k];
                    if (e == null || !seen.Add(e.EntityId)) continue;

                    if (IsTrout(e)) { if (!visitBusy.Contains(e.EntityId)) fishes.Add(e); }
                    else if (e is EntityItem ei) { if (InWater(ei)) foods[ei.EntityId] = ei; else foodsDry++; }   // so comida dentro da agua interessa
                }
            }

            if (foods.Count == 0)
            {
                if (foodsDry > 0)
                {
                    diagMs += (long)(dt * 1000);
                    if (diagMs >= 10000) { diagMs = 0; sapi.Logger.Notification("[pisciculture] alimentacao: " + foodsDry + " comida(s) fora da agua (ignoradas), peixes=" + fishes.Count); }
                }
                foreach (Entity fish in fishes) StopEating(fish);
                RelaxTilted(null);
                feedStates.Clear();
                busyFish.Clear();
                idleFeedTicks = 4;
                return;
            }

            long nowMs = sapi.World.ElapsedMilliseconds;

            // 1) Quem ja tem alvo valido continua com ele; conta quantos peixes disputam cada comida.
            Dictionary<long, int> claims = new Dictionary<long, int>();
            for (int i = 0; i < fishes.Count; i++)
            {
                Entity fish = fishes[i];
                FeedState st;
                if (!feedStates.TryGetValue(fish.EntityId, out st)) continue;
                if (st.TargetId < 0) continue;

                EntityItem t;
                if (!foods.TryGetValue(st.TargetId, out t) || !t.Alive || t.Itemstack == null || t.Itemstack.StackSize <= 0)
                {
                    ResetTarget(fish, st);
                    continue;
                }
                int c;
                claims.TryGetValue(st.TargetId, out c);
                claims[st.TargetId] = c + 1;
            }

            // Diagnostico (a cada ~5 s) para o log
            diagMs += (long)(dt * 1000);
            bool diag = diagMs >= 5000;
            if (diag)
            {
                diagMs = 0;
                PruneFeedStates(fishes);
            }
            int dFull = 0, dDry = 0, dPaused = 0, dTarget = 0, dNoPick = 0, dNotAccepted = 0, dTooFar = 0, dBusy = 0;

            // 2) Peixes sem alvo escolhem a comida mais proxima que ainda tenha "vaga".
            for (int i = 0; i < fishes.Count; i++)
            {
                Entity fish = fishes[i];
                FeedState st;
                if (!feedStates.TryGetValue(fish.EntityId, out st))
                {
                    st = new FeedState();
                    feedStates[fish.EntityId] = st;
                }
                if (st.TargetId >= 0) { dTarget++; continue; }
                if (nowMs < st.PausedUntilMs) { dPaused++; continue; }
                if (GetPortions(fish) >= MaxPortions) { dFull++; continue; }
                if (!InWater(fish)) { dDry++; continue; }

                EntityItem pick = null;
                double best = double.MaxValue;
                bool anyAccepted = false, anyNear = false;
                foreach (KeyValuePair<long, EntityItem> kv in foods)
                {
                    EntityItem item = kv.Value;
                    if (!item.Alive || item.Itemstack == null || item.Itemstack.StackSize <= 0) continue;
                    if (!Accepts(fish, item.Itemstack)) continue;
                    anyAccepted = true;

                    int c;
                    claims.TryGetValue(kv.Key, out c);
                    if (c >= Math.Min(MaxEatersPerItem, item.Itemstack.StackSize)) continue;

                    double dx = item.Pos.X - fish.Pos.X;
                    double dy = item.Pos.Y - fish.Pos.Y;
                    double dz = item.Pos.Z - fish.Pos.Z;
                    if (Math.Abs(dy) > SeekRangeVert) continue;
                    double hor = dx * dx + dz * dz;
                    if (hor > SeekRangeHor * SeekRangeHor) continue;
                    anyNear = true;
                    double d = hor + dy * dy;
                    if (d >= best) continue;
                    best = d;
                    pick = item;
                }

                if (pick == null)
                {
                    dNoPick++;
                    if (!anyAccepted) dNotAccepted++;
                    else if (!anyNear) dTooFar++;
                    else dBusy++;
                }
                if (pick != null)
                {
                    st.TargetId = pick.EntityId;
                    st.ChaseTime = 0;
                    st.EatTime = 0;
                    int c;
                    claims.TryGetValue(pick.EntityId, out c);
                    claims[pick.EntityId] = c + 1;
                }
            }

            if (diag)
            {
                sapi.Logger.Notification("[pisciculture] alimentacao: peixes=" + fishes.Count + " comidas=" + foods.Count + " nadando/comendo=" + dTarget + " cheios=" + dFull + " fora-da-agua=" + dDry + " em-pausa=" + dPaused + " sem-comida-alcancavel=" + dNoPick + " (especie-nao-aceita=" + dNotAccepted + " longe=" + dTooFar + " vagas-cheias/outro=" + dBusy + ")");
            }

            // 3) Cada peixe com alvo nada ate ele, ou come se ja chegou.
            HashSet<long> tiltKeep = new HashSet<long>();
            for (int i = 0; i < fishes.Count; i++)
            {
                Entity fish = fishes[i];
                FeedState st;
                if (!feedStates.TryGetValue(fish.EntityId, out st) || st.TargetId < 0) continue;

                EntityItem target = foods[st.TargetId];

                if (!InWater(fish) || GetPortions(fish) >= MaxPortions)
                {
                    ResetTarget(fish, st);
                    continue;
                }

                // Bloqueia as outras tarefas de IA enquanto o peixe cuida da comida (evita "espasmos").
                EntityBehaviorTaskAI ai = fish.GetBehavior<EntityBehaviorTaskAI>();
                if (ai != null && ai.TaskManager != null)
                {
                    EnsureHook(fish, ai.TaskManager);
                    if (busyFish.Add(fish.EntityId)) ai.TaskManager.StopTasks();
                }

                double lx = target.Pos.X - fish.Pos.X;
                double lz = target.Pos.Z - fish.Pos.Z;
                double ly = target.Pos.Y - fish.Pos.Y;
                // Peixes grandes tem a boca bem a frente do centro: e a boca (nao o corpo) que tem de chegar na comida.
                double mouth = Math.Min(0.8, 0.4 * Math.Max(fish.SelectionBox.XSize, fish.SelectionBox.ZSize));
                double centerDist = Math.Sqrt(lx * lx + lz * lz);
                double horToItem = Math.Max(0, centerDist - mouth);
                double dirX = centerDist > 0.001 ? lx / centerDist : 0, dirZ = centerDist > 0.001 ? lz / centerDist : 0;

                // Histerese: para comecar a comer precisa chegar perto; depois so desiste se for empurrado para longe.
                // O peixe come de baixo para cima: fica logo abaixo da comida (ly > 0 = comida acima do peixe).
                // Comida que afunda e fica no fundo: o peixe nao consegue ficar "abaixo" dela (e chao), entao come de lado, na altura dela.
                bool grounded = OnBottom(target);
                double startEat = 0.55, keepEat = 1.4;
                double lowStart = grounded ? -1.0 : 0.08, lowKeep = grounded ? -1.3 : -0.3;
                bool close = st.Eating ? (horToItem <= keepEat && ly >= lowKeep && ly <= 2.4) : (horToItem <= startEat && ly >= lowStart && ly <= 1.8);

                if (!close)
                {
                    if (st.Eating) StopEating(fish);
                    st.Eating = false;
                    st.EatTime = 0;

                    st.ChaseTime += dt;
                    if (st.ChaseTime > GiveUpSeconds)
                    {
                        st.PausedUntilMs = nowMs + GiveUpPauseMs;
                        ResetTarget(fish, st);
                        continue;
                    }

                    // Cada peixe mira um lugarzinho ao redor da comida (evita o amontoado).
                    double ang = (fish.EntityId % 12) * (Math.PI * 2 / 12.0);
                    double tx = target.Pos.X + Math.Cos(ang) * 0.2 - dirX * mouth - fish.Pos.X;
                    double tz = target.Pos.Z + Math.Sin(ang) * 0.2 - dirZ * mouth - fish.Pos.Z;
                    double tiltAmt = grounded ? MaxTilt(fish) : 0f;
                    double ty = target.Pos.Y + (grounded ? 0.08 + mouth * Math.Sin(tiltAmt) : -0.5) - fish.Pos.Y; // mira abaixo da comida (ou na altura dela, se estiver no fundo)
                    if (ty > -0.3 && !WaterAbove(fish, SurfaceMargin)) ty = -0.3;   // a animacao de comer levanta o corpo: fica sempre bem abaixo da superficie
                    double dist = Math.Sqrt(tx * tx + ty * ty + tz * tz);
                    if (dist < 0.01) dist = 0.01;

                    if (horToItem > 0.3) fish.Pos.Yaw = (float)Math.Atan2(lx, lz);
                    if (grounded && horToItem < 1.2) { EaseTilt(fish, FeedPitchSign * (float)tiltAmt); tiltKeep.Add(fish.EntityId); }

                    double speed = Math.Min(SwimSpeed, dist * 0.5 + 0.005);
                    fish.Pos.Motion.X = tx / dist * speed;
                    fish.Pos.Motion.Y = ty / dist * speed;
                    fish.Pos.Motion.Z = tz / dist * speed;
                }
                else
                {
                    // chegou: fica parado e come (animacao + particulas); so consome ao terminar
                    // sobe devagarinho para morder de baixo
                    bool deepEnough = WaterAbove(fish, SurfaceMargin);
                    if (grounded)
                    {
                        // Comida no fundo: o peixe se segura na altura da comida (sem isso a flutuacao o levanta e ele fica subindo e descendo).
                        double wantY = target.Pos.Y + 0.08 + mouth * Math.Sin(MaxTilt(fish)) - fish.Pos.Y;
                        fish.Pos.Motion.Set(0, Math.Max(-0.04, Math.Min(0.04, wantY * 0.6)), 0);
                    }
                    else fish.Pos.Motion.Set(0, !deepEnough ? -0.02 : (ly > 0.25 ? 0.012 : 0), 0);   // nunca sobe para fora da agua
                    if (horToItem > 0.2) fish.Pos.Yaw = (float)Math.Atan2(lx, lz);
                    if (!st.Eating)
                    {
                        st.Eating = true;
                        if (!grounded) fish.AnimManager.StartAnimation(eatAnim);
                        sapi.World.PlaySoundAt(new AssetLocation("sounds/effect/water-fill2"), fish.Pos.X, fish.Pos.Y, fish.Pos.Z, null, true, 16, 0.6f);
                    }

                    if (grounded) { EaseTilt(fish, FeedPitchSign * MaxTilt(fish)); tiltKeep.Add(fish.EntityId); }
                    st.EatTime += dt;
                    if (sapi.World.Rand.NextDouble() < 0.3)
                    {
                        sapi.World.SpawnCubeParticles(target.Pos.XYZ, target.Itemstack, 0.2f, 1, 0.2f + 0.3f * (float)sapi.World.Rand.NextDouble());
                    }
                    if (sapi.World.Rand.NextDouble() < 0.5)
                    {
                        SpawnBubbles(fish, 2f);
                    }

                    if (st.EatTime >= EatSeconds)
                    {
                        if (target.Itemstack != null && target.Itemstack.StackSize > 0)
                        {
                            // Migalhas da comida mordida (antes de consumir).
                            ItemStack eaten = target.Itemstack.Clone();
                            eaten.StackSize = 1;
                            sapi.World.SpawnCubeParticles(target.Pos.XYZ.Add(0, 0.05, 0), eaten, 0.25f, 14, 0.35f, null, new Vec3f(0, 0.3f, 0));
                            target.Itemstack.StackSize--;
                            if (target.Itemstack.StackSize <= 0) target.Die();

                            SetPortions(fish, Math.Min(MaxPortions, GetPortions(fish) + 1f));
                            
                            // Som da mordida e uma rajada de bolhinhas ao terminar a refeicao.
                            sapi.World.PlaySoundAt(new AssetLocation("sounds/creature/animal-eat-small"), fish.Pos.X, fish.Pos.Y, fish.Pos.Z, null, true, 20, 1f);
                            sapi.World.PlaySoundAt(new AssetLocation("sounds/effect/squish1"), fish.Pos.X, fish.Pos.Y, fish.Pos.Z, null, true, 20, 0.8f);
                            SpawnBubbles(fish, 8f);
                        }

                        ResetTarget(fish, st);
                    }
                }
            }

            RelaxTilted(tiltKeep);

            // Libera da lista de ocupados quem ficou sem alvo.
            busyFish.RemoveWhere(id =>
            {
                FeedState fs;
                return !feedStates.TryGetValue(id, out fs) || fs.TargetId < 0;
            });
        }

        /// <summary>Esquece o estado de peixes que sairam do alcance (mortos, descarregados, longe): evita vazamento e IA presa.</summary>
        void PruneFeedStates(List<Entity> present)
        {
            HashSet<long> ids = new HashSet<long>();
            for (int i = 0; i < present.Count; i++) ids.Add(present[i].EntityId);

            List<long> stale = null;
            foreach (long id in feedStates.Keys)
            {
                if (ids.Contains(id)) continue;
                if (stale == null) stale = new List<long>();
                stale.Add(id);
            }
            if (stale == null) return;
            for (int i = 0; i < stale.Count; i++)
            {
                feedStates.Remove(stale[i]);
                busyFish.Remove(stale[i]);
            }
        }

        /// <summary>Bolhinhas azuladas subindo perto da boca do peixe.</summary>
        void SpawnBubbles(Entity fish, float quantity)
        {
            double bx = fish.Pos.X + Math.Sin(fish.Pos.Yaw) * 0.15;
            double bz = fish.Pos.Z + Math.Cos(fish.Pos.Yaw) * 0.15;
            sapi.World.SpawnParticles(
                quantity,
                ColorUtil.ToRgba(170, 190, 225, 245),
                new Vec3d(bx - 0.05, fish.Pos.Y + 0.05, bz - 0.05),
                new Vec3d(bx + 0.05, fish.Pos.Y + 0.15, bz + 0.05),
                new Vec3f(-0.05f, 0.25f, -0.05f),
                new Vec3f(0.05f, 0.5f, 0.05f),
                1.1f,
                0f,
                0.25f,
                EnumParticleModel.Quad);
        }

        void ResetTarget(Entity fish, FeedState st)
        {
            if (st.Eating) StopEating(fish);
            st.Eating = false;
            st.TargetId = -1;
            st.EatTime = 0;
            st.ChaseTime = 0;
            busyFish.Remove(fish.EntityId);
        }

        void StopEating(Entity fish)
        {
            if (fish.AnimManager != null && fish.AnimManager.IsAnimationActive("rising-eat"))
            {
                fish.AnimManager.StopAnimation("rising-eat");
            }
        }

        /// <summary>
        /// Trutas de criacao (geracao 1 ou mais) nao somem sozinhas e ganham +0,5 de vida base por geracao.
        /// Como nos outros animais, o medo do jogador diminui a cada geracao (parte do jogo base)
        /// e some de vez na geracao TameGeneration; a partir dela a vida para de aumentar.
        /// </summary>
        void MakeFarmFish(Entity fish)
        {
            int gen = fish.WatchedAttributes.GetInt("generation", 0);
            if (gen < 1) return;

            for (int n = 0; n < 4; n++)
            {
                EntityBehavior despawn = fish.GetBehavior("despawn");
                if (despawn == null) break;
                fish.RemoveBehavior(despawn);
            }

            if (gen >= TameGeneration)
            {
                EntityBehaviorTaskAI ai = fish.GetBehavior<EntityBehaviorTaskAI>();
                if (ai != null && ai.TaskManager != null)
                {
                    IAiTask flee = ai.TaskManager.GetTask("fleecreature");
                    if (flee != null) ai.TaskManager.RemoveTask(flee);
                }
            }

            // Vida: base + 0,5 * geracao, limitada a geracao em que o medo acaba.
            int effGen = Math.Min(gen, TameGeneration);
            if (fish.WatchedAttributes.GetInt("pisciculHpGen", 0) == effGen) return;

            EntityBehaviorHealth hp = fish.GetBehavior<EntityBehaviorHealth>();
            if (hp == null) return;

            float orig = fish.WatchedAttributes.GetFloat("pisciculBaseHp", 0f);
            if (orig <= 0f)
            {
                orig = hp.BaseMaxHealth;
                fish.WatchedAttributes.SetFloat("pisciculBaseHp", orig);
            }

            hp.BaseMaxHealth = orig + HealthBonusPerGeneration * effGen;
            hp.UpdateMaxHealth();
            fish.WatchedAttributes.SetInt("pisciculHpGen", effGen);
        }

        /// <summary>Especie de um bloco/item de ova (codigo fishroe-ESPECIE-N ou fishroe-ESPECIE-wN). A especie e sempre a do proprio bloco.</summary>
        public static string RoeSpeciesOf(Block b)
        {
            string path = b?.Code?.Path;
            if (path == null || !path.StartsWith("fishroe-")) return DefaultSpecies;
            int last = path.LastIndexOf('-');
            if (last <= 8) return DefaultSpecies;
            return NormalizeSpecies(path.Substring(8, last - 8));
        }

        /// <summary>Ova seca/morta: variante dN do bloco.</summary>
        public static bool IsDeadRoe(Block b)
        {
            string path = b?.Code?.Path;
            if (path == null) return false;
            int last = path.LastIndexOf('-');
            return last >= 0 && last + 1 < path.Length && path[last + 1] == 'd';
        }

        public const double RoeDryDeathHours = 1.0;   // 1 h fora da agua: a ova seca e morre
        public const double RoeRotHours = 24.0;       // 24 h fora da agua: vira restos podres

        public static string NormalizeSpecies(string sp)
        {
            return (sp != null && SpeciesSet.Contains(sp)) ? sp : DefaultSpecies;
        }

        bool HasMate(Entity fish, List<Entity> allTrout)
        {
            string mySpecies = SpeciesOf(fish);
            for (int i = 0; i < allTrout.Count; i++)
            {
                Entity other = allTrout[i];
                if (other == fish || !other.Alive) continue;
                if (SpeciesOf(other) != mySpecies) continue;
                if (Math.Abs(other.Pos.Y - fish.Pos.Y) > MateRangeVert) continue;
                double dx = other.Pos.X - fish.Pos.X;
                double dz = other.Pos.Z - fish.Pos.Z;
                if (dx * dx + dz * dz <= MateRangeHor * MateRangeHor) return true;
            }
            return false;
        }

        /// <summary>
        /// Procura o fundo logo abaixo da truta e coloca ali um bloco de ova (dentro da agua).
        /// </summary>
        bool TryLayRoe(Entity fish, out BlockPos laidAt)
        {
            laidAt = null;
            Block roeBlock = sapi.World.GetBlock(new AssetLocation("pisciculture", "fishroe-" + (SpeciesOf(fish) ?? DefaultSpecies) + "-" + (1 + sapi.World.Rand.Next(4))));
            if (roeBlock == null)
            {
                sapi.Logger.Warning("[pisciculture] Bloco de ova 'pisciculture:fishroe-N' nao encontrado. Desova desativada.");
                return false;
            }

            IBlockAccessor ba = sapi.World.BlockAccessor;
            BlockPos pos = fish.Pos.AsBlockPos.Copy();

            for (int i = 0; i < 10; i++)
            {
                Block fluid = ba.GetBlock(pos, BlockLayersAccess.Fluid);
                if (fluid == null || fluid.LiquidCode != "water") return false;

                Block solidHere = ba.GetBlock(pos, BlockLayersAccess.Solid);
                if (solidHere == null || solidHere.Id != 0) return false;

                BlockPos belowPos = pos.DownCopy();
                Block below = ba.GetBlock(belowPos, BlockLayersAccess.Solid);
                if (below != null && below.Id != 0 && below.SideSolid[BlockFacing.UP.Index])
                {
                    ba.SetBlock(roeBlock.Id, pos, BlockLayersAccess.Solid);
                    if (ba.GetBlockEntity(pos) == null)
                    {
                        ba.SpawnBlockEntity("PiscicultureRoe", pos);
                    }
                    BlockEntityTroutRoe roeBe = ba.GetBlockEntity(pos) as BlockEntityTroutRoe;
                    if (roeBe != null)
                    {
                        int parentGen = fish.WatchedAttributes.GetInt("generation", 0);
                        roeBe.Generation = parentGen < 1 ? 0 : parentGen + 1; // ova selvagem nao tem geracao
                        roeBe.Species = SpeciesOf(fish) ?? DefaultSpecies;
                        roeBe.MarkDirty();
                    }
                    laidAt = pos.Copy();
                    return true;
                }

                pos.Y--;
            }

            return false;
        }

        // ------------------------------------------------------------------
        // Balde: Ctrl + Shift + botao direito pega o peixe (balde com agua) ou solta (balde com peixe)
        // ------------------------------------------------------------------

        void OnHandInteract(IServerPlayer player, EnumHandInteractNw mode, float secondsPassed, ref EnumHandling handling)
        {
            if (mode != EnumHandInteractNw.StartHeldItemUse) return;
            if (player == null || player.Entity == null) return;

            ItemSlot slot = player.InventoryManager.ActiveHotbarSlot;
            if (slot == null || slot.Empty || slot.Itemstack.Collectible == null) return;

            CollectibleObject held = slot.Itemstack.Collectible;

            if (held is BlockFishBucket)
            {
                // Shift + botao direito: coloca o balde (com o peixe dentro) no chao, como um balde comum.
                if (player.Entity.Controls.ShiftKey) return;

                // Como no Minecraft: botao direito com o balde de peixe solta o peixe na agua.
                sapi.Logger.Debug("[pisciculture] Clique direito com balde de peixe.");
                ReleaseFish(player, slot);
                handling = EnumHandling.PreventDefault;
            }
            else if (held is BlockLiquidContainerBase)
            {
                // Ovas so podem ser coletadas com um balde com agua.
                if (TryCollectRoe(player, slot)) { handling = EnumHandling.PreventDefault; return; }
                if (TryPlaceRoeFromBucket(player, slot)) { handling = EnumHandling.PreventDefault; return; }

                // Como no Minecraft: botao direito num peixe com um balde cheio de agua pega o peixe.
                Entity target = FindFishInSight(player);
                if (target == null) return;

                sapi.Logger.Debug("[pisciculture] Balde (" + held.Code + ") clicou no peixe " + target.Code + ".");
                if (held is BlockBucket && TryCaptureFish(player, slot, target))
                {
                    handling = EnumHandling.PreventDefault;
                }
            }
        }

        /// <summary>Ovas dentro do balde: itens "roeportion-ESPECIE", cada ova = 1 litro (maximo 10 = balde cheio).</summary>
        public const int RoeBucketMax = 10;

        static bool IsRoePortion(ItemStack st)
        {
            string path = st?.Collectible?.Code?.Path;
            return path != null && path.StartsWith("roeportion-") && st.Collectible.Code.Domain == "pisciculture";
        }

        static bool IsRoeBucket(CollectibleObject c)
        {
            return c != null && c.Code != null && c.Code.Domain == "pisciculture" && c.Code.Path.StartsWith("roebucket-");
        }

        /// <summary>Monta o "balde com ovas" para N ovas (cada nivel tem um modelo 3D com mais ovas), ou o balde comum se N = 0.</summary>
        ItemStack MakeRoeBucket(int count, ItemStack portionTemplate, string originalBucketCode)
        {
            if (count <= 0)
            {
                Block plain = sapi.World.GetBlock(new AssetLocation(originalBucketCode)) ?? sapi.World.GetBlock(new AssetLocation("game", "woodbucket"));
                return plain == null ? null : new ItemStack(plain);
            }

            Block rb = sapi.World.GetBlock(new AssetLocation("pisciculture", "roebucket-" + Math.Min(count, RoeBucketMax)));
            BlockBucket rbb = rb as BlockBucket;
            if (rbb == null) return null;

            ItemStack stack = new ItemStack(rb);
            stack.Attributes.SetString(KeyBucketCode, originalBucketCode);
            ItemStack content = portionTemplate.Clone();
            content.StackSize = Math.Min(count, RoeBucketMax);
            rbb.SetContent(stack, content);
            return stack;
        }

        /// <summary>Balde vazio (sem agua) apontado para uma ova: recolhe a ova para dentro do balde (1 ova = 1 litro).</summary>
        bool TryCollectRoe(IServerPlayer player, ItemSlot slot)
        {
            BlockSelection sel = player.CurrentBlockSelection;
            if (sel == null) return false;

            IBlockAccessor ba = sapi.World.BlockAccessor;
            BlockPos roePos = sel.Position;
            Block roe = ba.GetBlock(roePos, BlockLayersAccess.Solid);
            if (!(roe is BlockFishRoe))
            {
                roePos = sel.Position.AddCopy(sel.Face);
                roe = ba.GetBlock(roePos, BlockLayersAccess.Solid);
                if (!(roe is BlockFishRoe)) return false;
            }

            if (IsDeadRoe(roe))
            {
                Tell(player, "pisciculture:msg-roe-dead");
                return true;
            }

            BlockBucket bucket = slot.Itemstack.Collectible as BlockBucket;
            if (bucket == null) return false;
            bool isRoeBucket = IsRoeBucket(bucket);
            ItemStack content = bucket.GetContent(slot.Itemstack);
            if (content != null && !IsRoePortion(content))
            {
                Tell(player, "pisciculture:msg-roe-needs-empty-bucket");
                return true;
            }

            BlockEntityTroutRoe be = ba.GetBlockEntity(roePos) as BlockEntityTroutRoe;
            string species = be != null ? be.Species : RoeSpeciesOf(roe);
            int gen = be != null ? be.Generation : 0;

            Item portionItem = sapi.World.GetItem(new AssetLocation("pisciculture", "roeportion-" + species));
            if (portionItem == null) return false;
            ItemStack portion = new ItemStack(portionItem, 1);
            if (gen > 0) portion.Attributes.SetInt("generation", gen); // ova selvagem nao tem geracao

            int have = content != null ? content.StackSize : 0;
            if (content != null && (content.Collectible.Code.Path != portion.Collectible.Code.Path || content.Attributes.GetInt("generation", 0) != gen))
            {
                Tell(player, "pisciculture:msg-roe-mismatch");
                return true;
            }
            if (have >= RoeBucketMax)
            {
                Tell(player, "pisciculture:msg-roe-bucket-full");
                return true;
            }

            string orig = isRoeBucket ? slot.Itemstack.Attributes.GetString(KeyBucketCode, "game:woodbucket") : slot.Itemstack.Collectible.Code.ToString();
            ItemStack updated = MakeRoeBucket(have + 1, portion, orig);
            if (updated == null) return false;

            ba.SetBlock(0, roePos, BlockLayersAccess.Solid);
            slot.Itemstack = updated;
            slot.MarkDirty();
            sapi.World.PlaySoundAt(new AssetLocation("sounds/block/water"), roePos.X + 0.5, roePos.Y + 0.5, roePos.Z + 0.5, player);
            return true;
        }

        /// <summary>Balde com ovas apontado para a agua: coloca uma ova no fundo (uma por clique, 1 litro).</summary>
        bool TryPlaceRoeFromBucket(IServerPlayer player, ItemSlot slot)
        {
            BlockBucket bucket = slot.Itemstack.Collectible as BlockBucket;
            if (bucket == null || !IsRoeBucket(bucket)) return false;
            ItemStack content = bucket.GetContent(slot.Itemstack);
            if (content == null || !IsRoePortion(content)) return false;

            BlockPos water = FindWaterTarget(player);
            BlockSelection selPlace = player.CurrentBlockSelection;
            if (water == null && selPlace == null) return false;

            string path = content.Collectible.Code.Path;
            string species = NormalizeSpecies(path.Substring("roeportion-".Length));
            IBlockAccessor ba = sapi.World.BlockAccessor;

            BlockPos pos = null;
            bool placed = false;
            if (water != null)
            {
                pos = water.Copy();
                for (int i = 0; i < 10; i++)
                {
                    Block fluid = ba.GetBlock(pos, BlockLayersAccess.Fluid);
                    Block solidHere = ba.GetBlock(pos, BlockLayersAccess.Solid);
                    if (fluid == null || fluid.LiquidCode != "water" || solidHere == null || solidHere.Id != 0) break;
                    Block below = ba.GetBlock(pos.DownCopy(), BlockLayersAccess.Solid);
                    if (below != null && below.Id != 0 && below.SideSolid[BlockFacing.UP.Index]) { placed = true; break; }
                    pos.Y--;
                }
            }
            else
            {
                // Fora da agua tambem pode (a ova seca em 1 h): coloca em cima do bloco apontado.
                if (selPlace.Face != BlockFacing.UP) return true;
                pos = selPlace.Position.UpCopy();
                Block here = ba.GetBlock(pos, BlockLayersAccess.Solid);
                Block under = ba.GetBlock(selPlace.Position, BlockLayersAccess.Solid);
                placed = here != null && here.Id == 0 && under != null && under.Id != 0 && under.SideSolid[BlockFacing.UP.Index];
            }
            if (!placed) return true;

            Block roeBlock = sapi.World.GetBlock(new AssetLocation("pisciculture", "fishroe-" + species + "-" + (1 + sapi.World.Rand.Next(4))));
            if (roeBlock == null) return true;

            ba.SetBlock(roeBlock.Id, pos, BlockLayersAccess.Solid);
            if (ba.GetBlockEntity(pos) == null) ba.SpawnBlockEntity("PiscicultureRoe", pos);
            BlockEntityTroutRoe be = ba.GetBlockEntity(pos) as BlockEntityTroutRoe;
            if (be != null)
            {
                be.Species = species;
                be.Generation = content.Attributes.GetInt("generation", 0);
                be.MarkDirty();
            }

            string orig = slot.Itemstack.Attributes.GetString(KeyBucketCode, "game:woodbucket");
            ItemStack updated = MakeRoeBucket(content.StackSize - 1, content, orig);
            if (updated != null) slot.Itemstack = updated;
            slot.MarkDirty();
            sapi.World.PlaySoundAt(new AssetLocation("sounds/block/water"), pos.X + 0.5, pos.Y + 0.5, pos.Z + 0.5, player);
            return true;
        }

        /// <summary>Peixe que o jogador esta mirando (ou o mais proximo da linha de visao, ate ~4,5 blocos).</summary>
        Entity FindFishInSight(IServerPlayer player)
        {
            Entity sel = player.CurrentEntitySelection?.Entity;
            if (sel != null && sel.Alive && IsAnyTrout(sel)) return sel;

            Vec3d eye = player.Entity.Pos.XYZ.Add(0, player.Entity.LocalEyePos.Y, 0);
            Vec3f view = player.Entity.Pos.GetViewVector();

            Entity best = null;
            double bestT = double.MaxValue;
            Entity[] around = sapi.World.GetEntitiesAround(eye, 6f, 6f, e => e.Alive && IsAnyTrout(e));
            for (int i = 0; i < around.Length; i++)
            {
                Entity f = around[i];
                double dx = f.Pos.X - eye.X;
                double dy = f.Pos.Y + 0.1 - eye.Y;
                double dz = f.Pos.Z - eye.Z;
                double t = dx * view.X + dy * view.Y + dz * view.Z;
                if (t < 0.2 || t > 4.5) continue;
                double px = dx - view.X * t, py = dy - view.Y * t, pz = dz - view.Z * t;
                double perp = Math.Sqrt(px * px + py * py + pz * pz);
                if (perp > 0.8) continue;
                if (t < bestT) { bestT = t; best = f; }
            }
            return best;
        }

        void Tell(IServerPlayer player, string key)
        {
            player.SendMessage(GlobalConstants.GeneralChatGroup, Lang.GetL(player.LanguageCode, key), EnumChatType.Notification);
        }

        /// <summary>Peixes adultos grandes demais para caber num balde (os alevinos cabem).</summary>
        public static readonly HashSet<string> BigFishSpecies = new HashSet<string> { "sheatfish-white", "sheatfish-black", "arapaima-gigas", "arapaima-arapaima", "pike-northern", "pickerel-chain" };
        public static bool TooBigForBucket(string species) { return BigFishSpecies.Contains(species); }

        bool TryCaptureFish(IServerPlayer player, ItemSlot slot, Entity target)
        {
            BlockBucket bucket = slot.Itemstack.Collectible as BlockBucket;
            if (bucket == null) return false;


            ItemStack content = bucket.GetContent(slot.Itemstack);
            bool hasWater = content != null && content.Collectible != null && content.StackSize > 0 && content.Collectible.Code.Path.Contains("water");
            if (!hasWater)
            {
                sapi.Logger.Notification("[pisciculture] Balde sem agua valida: conteudo=" + (content?.Collectible?.Code?.ToString() ?? "nenhum") + " x" + (content?.StackSize ?? 0) + " litros=" + bucket.GetCurrentLitres(slot.Itemstack));
                Tell(player, "pisciculture:msg-bucket-needs-water");
                return true;
            }

            bool juvenile = IsJuvenile(target);
            if (!juvenile && TooBigForBucket(SpeciesOf(target)))
            {
                Tell(player, "pisciculture:msg-fish-too-big");
                return true;
            }
            Block fishBucketBlock = sapi.World.GetBlock(new AssetLocation("pisciculture", "fishbucket-" + SpeciesOf(target) + (juvenile ? "-juvenile" : "-adult")));
            BlockFishBucket fishBucket = fishBucketBlock as BlockFishBucket;
            if (fishBucket == null)
            {
                sapi.Logger.Warning("[pisciculture] Bloco do balde com peixe nao encontrado.");
                return false;
            }

            double nowDays = sapi.World.Calendar.TotalDays;
            double nowHours = sapi.World.Calendar.TotalHours;

            TreeAttribute fishTree = new TreeAttribute();
            fishTree.SetString("code", target.Code.ToString());
            fishTree.SetInt("generation", target.WatchedAttributes.GetInt("generation", 0));
            fishTree.SetFloat("portions", GetPortions(target));
            fishTree.SetFloat("weight", target.WatchedAttributes.GetFloat("animalWeight", 0.75f));
            double gravidEnd = target.WatchedAttributes.GetDouble(KeyGravidUntil, 0.0);
            if (gravidEnd > 0)
            {
                fishTree.SetDouble("gravidLeft", Math.Max(0.0, gravidEnd - nowDays));
                fishTree.SetDouble("gravidTotal", Math.Max(0.01, gravidEnd - target.WatchedAttributes.GetDouble(KeyGravidStart, gravidEnd - 1)));
            }
            EntityBehaviorHealth capHp = target.GetBehavior<EntityBehaviorHealth>();
            if (capHp != null)
            {
                fishTree.SetFloat("hp", capHp.Health);
                fishTree.SetFloat("maxhp", capHp.MaxHealth);
            }
            fishTree.SetDouble("cooldownLeft", Math.Max(0.0, GetCooldown(target) - nowDays));

            ITreeAttribute growTree = target.WatchedAttributes.GetTreeAttribute("grow");
            double ageHours = 0;
            if (growTree != null) ageHours = Math.Max(0.0, nowHours - growTree.GetDouble("timeSpawned", nowHours));
            fishTree.SetDouble("ageHours", ageHours);

            ItemStack newStack = new ItemStack(fishBucket);
            fishBucket.SetContent(newStack, content.Clone());
            newStack.Attributes[KeyBucketFish] = fishTree;
            newStack.Attributes.SetString(KeyBucketCode, slot.Itemstack.Collectible.Code.ToString());

            // Tira o peixe do mundo.
            target.Die(EnumDespawnReason.PickedUp);

            // Troca o balde na mao (se havia varios baldes empilhados, so um recebe o peixe).
            if (slot.Itemstack.StackSize > 1)
            {
                slot.Itemstack.StackSize--;
                slot.MarkDirty();
                if (!player.InventoryManager.TryGiveItemstack(newStack, true))
                {
                    sapi.World.SpawnItemEntity(newStack, player.Entity.Pos.XYZ);
                }
            }
            else
            {
                slot.Itemstack = newStack;
                slot.MarkDirty();
            }

            sapi.World.PlaySoundAt(new AssetLocation("sounds/block/water"), player.Entity.Pos.X, player.Entity.Pos.Y, player.Entity.Pos.Z, player);
            return true;
        }

        BlockPos FindWaterTarget(IServerPlayer player)
        {
            BlockSelection sel = player.CurrentBlockSelection;
            if (sel == null) return null;

            IBlockAccessor ba = sapi.World.BlockAccessor;

            Block fluid = ba.GetBlock(sel.Position, BlockLayersAccess.Fluid);
            if (fluid != null && fluid.LiquidCode == "water") return sel.Position.Copy();

            BlockPos next = sel.Position.AddCopy(sel.Face);
            fluid = ba.GetBlock(next, BlockLayersAccess.Fluid);
            if (fluid != null && fluid.LiquidCode == "water") return next;

            return null;
        }

        void ReleaseFish(IServerPlayer player, ItemSlot slot)
        {
            ItemStack stack = slot.Itemstack;
            BlockFishBucket fishBucket = stack.Collectible as BlockFishBucket;
            ITreeAttribute fishTree = stack.Attributes.GetTreeAttribute(KeyBucketFish);
            if (fishBucket == null || fishTree == null) return;

            // Na agua: o peixe nada. Fora dela: cai no chao e se debate ate morrer (comportamento do jogo base).
            BlockPos waterPos = FindWaterTarget(player);
            Vec3d spawnPos;
            if (waterPos != null)
            {
                spawnPos = new Vec3d(waterPos.X + 0.5, waterPos.Y + 0.5, waterPos.Z + 0.5);
            }
            else
            {
                BlockSelection sel = player.CurrentBlockSelection;
                if (sel == null)
                {
                    Tell(player, "pisciculture:msg-release-in-water");
                    return;
                }
                BlockPos np = sel.Position.AddCopy(sel.Face);
                spawnPos = new Vec3d(np.X + 0.5, np.Y + 0.1, np.Z + 0.5);
                waterPos = np;
            }

            string code = fishTree.GetString("code", "");
            EntityProperties type = sapi.World.GetEntityType(new AssetLocation(code));
            if (type == null)
            {
                sapi.Logger.Warning("[pisciculture] Tipo de peixe '" + code + "' nao encontrado ao soltar.");
                return;
            }

            double nowDays = sapi.World.Calendar.TotalDays;
            double nowHours = sapi.World.Calendar.TotalHours;

            Entity fish = sapi.World.ClassRegistry.CreateEntity(type);
            fish.Pos.SetPos(spawnPos.X, spawnPos.Y, spawnPos.Z);
            fish.Pos.Yaw = player.Entity.Pos.Yaw;
            fish.WatchedAttributes.SetInt("generation", fishTree.GetInt("generation", 0));
            SetPortions(fish, fishTree.GetFloat("portions", 0f));
            if (fishTree.HasAttribute("weight"))
            {
                fish.WatchedAttributes.SetFloat("animalWeight", fishTree.GetFloat("weight", 0.75f));
                fish.WatchedAttributes.SetBool("pisciculWeightSet", true);
            }
            if (fishTree.HasAttribute("gravidLeft"))
            {
                double left = fishTree.GetDouble("gravidLeft", 0.0);
                double total = fishTree.GetDouble("gravidTotal", 1.0);
                fish.WatchedAttributes.SetDouble(KeyGravidUntil, nowDays + left);
                fish.WatchedAttributes.SetDouble(KeyGravidStart, nowDays + left - total);
            }

            double cooldownLeft = fishTree.GetDouble("cooldownLeft", 0.0);
            if (cooldownLeft > 0) SetCooldown(fish, nowDays + cooldownLeft);

            if (type.Code.Domain == "pisciculture" && SpeciesOfCode(type.Code) != null)
            {
                TreeAttribute growTree = new TreeAttribute();
                growTree.SetDouble("timeSpawned", nowHours - fishTree.GetDouble("ageHours", 0.0));
                fish.WatchedAttributes["grow"] = growTree;
            }

            sapi.World.SpawnEntity(fish);

            // Volta a ser um balde comum, mantendo a agua.
            string bucketCode = stack.Attributes.GetString(KeyBucketCode, "game:woodbucket");
            Block plainBlock = sapi.World.GetBlock(new AssetLocation(bucketCode));
            if (plainBlock == null) plainBlock = sapi.World.GetBlock(new AssetLocation("game", "woodbucket"));
            BlockLiquidContainerBase plainBucket = plainBlock as BlockLiquidContainerBase;
            if (plainBucket != null)
            {
                ItemStack content = fishBucket.GetContent(stack);
                ItemStack back = new ItemStack(plainBlock);
                if (content != null) plainBucket.SetContent(back, content.Clone());
                slot.Itemstack = back;
                slot.MarkDirty();
            }

            sapi.World.PlaySoundAt(new AssetLocation("sounds/block/water"), waterPos.X + 0.5, waterPos.Y + 0.5, waterPos.Z + 0.5, player);
        }

        // ------------------------------------------------------------------
        // Comando de estado
        // ------------------------------------------------------------------

        static string TL(string key, string langCode)
        {
            string k = "pisciculture:" + key;
            return langCode == null ? Lang.Get(k) : Lang.GetL(langCode, k);
        }

        TextCommandResult OnCmdStatus(TextCommandCallingArgs args)
        {
            IPlayer player = args.Caller.Player;
            if (player == null || player.Entity == null) return TextCommandResult.Error(Lang.Get("pisciculture:cmd-ingame"));

            Vec3d center = player.Entity.Pos.XYZ;
            double now = sapi.World.Calendar.TotalDays;
            IServerPlayer splr = player as IServerPlayer;
            string langCode = splr != null ? splr.LanguageCode : null;

            int total = 0;
            int ready = 0;
            int young = 0;
            StringBuilder sb = new StringBuilder();

            Entity[] nearby = sapi.World.GetEntitiesAround(center, 32f, 16f, ent => ent.Alive && IsAnyTrout(ent));
            for (int n = 0; n < nearby.Length; n++)
            {
                Entity e = nearby[n];
                if (e == null) continue;

                if (IsJuvenile(e))
                {
                    young++;
                    continue;
                }

                if (!IsTrout(e)) continue;

                total++;
                float portions = GetPortions(e);
                double cooldownLeft = GetCooldown(e) - now;
                bool isReady = portions >= PortionsToBreed && cooldownLeft <= 0;
                if (isReady) ready++;

                if (total <= 10)
                {
                    string spKey = "pisciculture:fish-name-" + NormalizeSpecies(SpeciesOf(e));
                    string spName = langCode == null ? Lang.Get(spKey) : Lang.GetL(langCode, spKey);
                    sb.Append("\n- ").Append(spName).Append(" (").Append(DietText(SpeciesOf(e), langCode)).Append("): ")
                      .Append(portions.ToString("0.#")).Append("/").Append(PortionsToBreed.ToString("0.#"))
                      .Append(" ").Append(TL("cmd-portions", langCode));
                    if (cooldownLeft > 0) sb.Append(", ").Append(TL("cmd-wait", langCode)).Append(" ").Append(cooldownLeft.ToString("0.0")).Append(" ").Append(TL("cmd-days", langCode));
                    else sb.Append(isReady ? ", " + TL("cmd-ready", langCode) : ", " + TL("cmd-nowait", langCode));
                }
            }

            if (total == 0 && young == 0) return TextCommandResult.Success(TL("cmd-none", langCode));

            string header = TL("cmd-adults", langCode) + ": " + total + " (" + TL("cmd-readycount", langCode) + ": " + ready + "). " + TL("cmd-young", langCode) + ": " + young + ".";
            return TextCommandResult.Success(header + sb.ToString());
        }
    }

    /// <summary>
    /// Peixe do mod: os peixes domesticados (geracao 1 ou mais) podem ser abatidos, mas so com lancas
    /// (golpeando ou arremessando); os selvagens nao podem ser feridos por jogadores (so pescados).
    /// </summary>
    public class EntityPiscicultureFish : EntityFish
    {
        bool spearStrike;

        bool IsDomesticated { get { return WatchedAttributes.GetInt("generation", 0) >= 1; } }

        static bool IsSpear(CollectibleObject c)
        {
            return c != null && c.Tool == EnumTool.Spear;
        }

        bool FromSpear(DamageSource src)
        {
            if (spearStrike) return true;
            EntityProjectile proj = src.SourceEntity as EntityProjectile;
            return proj != null && proj.ProjectileStack != null && IsSpear(proj.ProjectileStack.Collectible);
        }

        /// <summary>Peixes com carcaca (comportamento harvestable) rendem a carne ao serem abertos, nao ao morrer.</summary>
        public override ItemStack[] GetDrops(IWorldAccessor world, BlockPos pos, IPlayer byPlayer)
        {
            if (GetBehavior("harvestable") != null) return null;
            return base.GetDrops(world, pos, byPlayer);
        }

        public override bool ReceiveDamage(DamageSource damageSource, float damage)
        {
            if (damageSource != null && damageSource.Type != EnumDamageType.Heal && damageSource.GetCauseEntity() is EntityPlayer)
            {
                if (!IsDomesticated || !FromSpear(damageSource)) return false;
            }
            return base.ReceiveDamage(damageSource, damage);
        }

        public override void OnInteract(EntityAgent byEntity, ItemSlot slot, Vec3d hitPosition, EnumInteractMode mode)
        {
            // O peixe comum ignora golpes (so foge) enquanto nada; o domesticado leva o golpe de uma lanca.
            if (mode == EnumInteractMode.Attack && Swimming && Alive && IsDomesticated && slot != null && slot.Itemstack != null && IsSpear(slot.Itemstack.Collectible))
            {
                if (World.Side == EnumAppSide.Server) Strike(byEntity, slot, hitPosition);
                return;
            }
            base.OnInteract(byEntity, slot, hitPosition, mode);
        }

        void Strike(EntityAgent byEntity, ItemSlot slot, Vec3d hitPosition)
        {
            ItemStack stack = slot.Itemstack;
            float damage = stack.Collectible.GetAttackPower(stack);
            int tier = stack.Collectible.GetToolTier(slot);

            damage *= byEntity.Stats.GetBlended("meleeWeaponsDamage");
            bool crit = false;
            damage = stack.Collectible.GetDamageToEntity(damage, this, stack, ref crit);

            EntityPlayer ep = byEntity as EntityPlayer;
            IPlayer byPlayer = ep == null ? null : ep.Player;
            if (byPlayer != null) stack.Collectible.OnAttackingWith(byEntity.World, byEntity, this, slot);

            DamageSource src = new DamageSource()
            {
                Source = byPlayer == null ? EnumDamageSource.Entity : EnumDamageSource.Player,
                SourceEntity = byEntity,
                Type = EnumDamageType.PiercingAttack,
                HitPosition = hitPosition,
                DamageTier = tier
            };

            spearStrike = true;
            try
            {
                if (ReceiveDamage(src, damage)) byEntity.DidAttack(src, this);
            }
            finally
            {
                spearStrike = false;
            }
        }
    }

    /// <summary>
    /// Item de peixe: o jogo procura o comportamento do manual pelo tipo exato, entao ensinamos o item a
    /// aceitar o nosso (que herda do original).
    /// </summary>
    public class ItemPiscicultureCreature : ItemCreature
    {
        protected override CollectibleBehavior GetBehavior(CollectibleBehavior[] fromList, Type type, bool withInheritance)
        {
            return base.GetBehavior(fromList, type, withInheritance || type == typeof(CollectibleBehaviorHandbookTextAndExtraInfo));
        }
    }

    /// <summary>Pagina do manual dos peixes: igual a padrao, mas os icones de "Pode comer" saem sem o fundo claro.</summary>
    public class CollectibleBehaviorPiscicultureHandbook : CollectibleBehaviorHandbookTextAndExtraInfo
    {
        static readonly System.Reflection.FieldInfo clickField = typeof(SlideshowItemstackTextComponent).GetField("onStackClicked", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);

        public CollectibleBehaviorPiscicultureHandbook(CollectibleObject collObj) : base(collObj) { }

        public override RichTextComponentBase[] GetHandbookInfo(ItemSlot inSlot, ICoreClientAPI capi, ItemStack[] allStacks, ActionConsumable<string> openDetailPageFor)
        {
            RichTextComponentBase[] comps = base.GetHandbookInfo(inSlot, capi, allStacks, openDetailPageFor);
            if (comps == null) return comps;
            for (int i = 0; i < comps.Length; i++)
            {
                SlideshowItemstackTextComponent ss = comps[i] as SlideshowItemstackTextComponent;
                if (ss == null) continue;
                ss.Background = false;

                // Icones de "Pode comer": clicar leva a pagina do item no manual (como nos outros itens).
                if (clickField != null && clickField.GetValue(ss) == null)
                {
                    clickField.SetValue(ss, (Action<ItemStack>)(cs =>
                    {
                        string code = cs.Collectible.GetCollectibleInterface<IHandBookPageCodeProvider>() == null
                            ? GuiHandbookItemStackPage.PageCodeForStack(cs)
                            : cs.Collectible.GetCollectibleInterface<IHandBookPageCodeProvider>().HandbookPageCodeForStack(capi.World, cs);
                        openDetailPageFor(code);
                    }));
                }
            }
            return comps;
        }
    }

    /// <summary>Mostra a dieta (carnivoro, herbivoro ou onivoro) ao olhar para um peixe, selvagem ou de criacao.</summary>
    /// <summary>
    /// Carcaca do peixe: a carne depende do tamanho da especie e do peso (condicao fisica, definida pela alimentacao);
    /// peixes com ovas podem trazer ovas na carcaca.
    /// </summary>
    public class EntityBehaviorPiscicultureHarvestable : EntityBehaviorHarvestable, IHarvestableDrops
    {
        public const double RoeInCarcassChance = 0.8;

        public EntityBehaviorPiscicultureHarvestable(Entity entity) : base(entity) { }

        // Peixes novos (selvagens, por exemplo) nascem com pesos bem variados, de magros a gordos.
        public override void AfterInitialized(bool onSpawn)
        {
            base.AfterInitialized(onSpawn);
            if (onSpawn && entity.World.Side == EnumAppSide.Server && !entity.WatchedAttributes.HasAttribute("pisciculWeightSet"))
            {
                entity.WatchedAttributes.SetFloat("animalWeight", 0.5f + 0.5f * (float)entity.World.Rand.NextDouble());
                entity.WatchedAttributes.SetBool("pisciculWeightSet", true);
            }
        }

        // O peso do jogo base muda com o clima; aqui ele vem da alimentacao (ver a digestao do mod).
        public override void OnGameTick(float deltaTime) { }

        public ItemStack[] GetHarvestableDrops(IWorldAccessor world, BlockPos pos, IPlayer byPlayer)
        {
            string sp = PiscicultureSystem.SpeciesOf(entity);
            List<ItemStack> result = new List<ItemStack>();
            Random rand = new Random();

            float weight = Math.Max(0.5f, Math.Min(1f, entity.WatchedAttributes.GetFloat("animalWeight", 0.75f)));
            float lootStat = 1f;
            if (byPlayer != null && byPlayer.Entity != null) lootStat = byPlayer.Entity.Stats.GetBlended("animalLootDropRate");

            double qty = PiscicultureSystem.BaseMeatCount(sp) * weight * dropQuantityMultiplier * lootStat * PiscicultureSystem.GoodHuntingMeatFactor(world.Api);
            int n = (int)Math.Floor(qty);
            if (rand.NextDouble() < qty - n) n++;
            if (n < 1) n = 1;

            Item meat = world.GetItem(new AssetLocation("game", entity.Code.Path.Replace("fish-freshwater", "fishraw-freshwater")));
            if (meat != null)
            {
                while (n > 0)
                {
                    int take = Math.Min(n, Math.Max(1, meat.MaxStackSize));
                    result.Add(new ItemStack(meat, take));
                    n -= take;
                }
            }

            // Peixe com ovas: chance de encontrar as ovas (para criar) na carcaca.
            if (sp != null && entity.WatchedAttributes.GetDouble(PiscicultureSystem.KeyGravidUntil, 0.0) > 0 && rand.NextDouble() < RoeInCarcassChance)
            {
                Block roe = world.GetBlock(new AssetLocation("pisciculture", "fishroe-" + sp + "-1"));
                if (roe != null)
                {
                    ItemStack roeStack = new ItemStack(roe, 2 + rand.Next(1 + (int)Math.Round(3 * weight)));
                    int parentGen = entity.WatchedAttributes.GetInt("generation", 0);
                    int gen = parentGen < 1 ? 0 : parentGen + 1;
                    if (gen > 0) roeStack.Attributes.SetInt("generation", gen);
                    result.Add(roeStack);
                }
            }

            return result.ToArray();
        }
    }

    public class EntityBehaviorPiscicultureInfo : EntityBehavior
    {
        public EntityBehaviorPiscicultureInfo(Entity entity) : base(entity) { }

        public override string PropertyName() { return "piscicultureinfo"; }

        long lastWarnMs;

        /// <summary>Lancas (de mao ou arremessadas) nao ferem peixes selvagens (geracao 0); so os peixes de criacao podem ser abatidos assim.</summary>
        public override void OnEntityReceiveDamage(DamageSource damageSource, ref float damage)
        {
            if (damageSource == null || damage <= 0f || entity.World == null || entity.World.Side != EnumAppSide.Server) return;
            if (entity.Code == null || entity.Code.Domain != "game") return;                  // alevinos do mod ja sao de criacao
            if (entity.WatchedAttributes.GetInt("generation", 0) > 0) return;                  // peixe de criacao
            if (!IsSpearAttack(damageSource)) return;

            damage = 0f;

            IServerPlayer splr = (damageSource.GetCauseEntity() as EntityPlayer)?.Player as IServerPlayer;
            long now = entity.World.ElapsedMilliseconds;
            if (splr != null && now - lastWarnMs > 4000)
            {
                lastWarnMs = now;
                splr.SendMessage(GlobalConstants.GeneralChatGroup, Lang.GetL(splr.LanguageCode, "pisciculture:msg-wild-fish-spear"), EnumChatType.Notification);
            }
        }

        static bool IsSpearAttack(DamageSource ds)
        {
            EntityProjectileBase proj = ds.SourceEntity as EntityProjectileBase;
            if (proj != null)
            {
                ItemStack st = proj.WeaponStack ?? proj.ProjectileStack;
                return st != null && st.Collectible != null && st.Collectible.Tool == EnumTool.Spear;
            }
            EntityAgent agent = ds.GetCauseEntity() as EntityAgent;
            ItemStack held = agent?.RightHandItemSlot?.Itemstack;
            return held != null && held.Collectible != null && held.Collectible.Tool == EnumTool.Spear;
        }

        public override void GetInfoText(StringBuilder infotext)
        {
            string sp = PiscicultureSystem.SpeciesOf(entity);
            if (sp == null) return;
            infotext.AppendLine(Lang.Get("pisciculture:info-diet", PiscicultureSystem.DietText(sp)));

            double until = entity.WatchedAttributes.GetDouble(PiscicultureSystem.KeyGravidUntil, 0.0);
            if (until > 0 && entity.Alive)
            {
                double start = entity.WatchedAttributes.GetDouble(PiscicultureSystem.KeyGravidStart, until - 1);
                double nowDay = entity.World.Calendar.TotalDays;
                int pct = (int)Math.Max(0, Math.Min(100, (nowDay - start) / Math.Max(0.01, until - start) * 100));
                infotext.AppendLine(Lang.Get("pisciculture:info-gravid", pct));
            }
        }
    }

    /// <summary>Texto com as informacoes do peixe guardado no balde (usado na dica do item e do bloco).</summary>
    public static class FishBucketInfo
    {
        public static void Append(ITreeAttribute fishTree, StringBuilder dsc)
        {
            if (fishTree == null) return;

            string code = fishTree.GetString("code", "");
            bool juvenile = code.Contains("juvenile");
            string speciesName = Lang.Get("pisciculture:fish-name-" + PiscicultureSystem.NormalizeSpecies(PiscicultureSystem.SpeciesOfCode(new AssetLocation(code))));
            dsc.AppendLine(Lang.Get("pisciculture:info-fish", Lang.Get(juvenile ? "pisciculture:info-species-juvenile" : "pisciculture:info-species-adult", speciesName)));
            dsc.AppendLine(Lang.Get("pisciculture:info-diet", PiscicultureSystem.DietText(PiscicultureSystem.SpeciesOfCode(new AssetLocation(code)))));
            if (fishTree.GetInt("generation", 0) > 0)
            {
                dsc.AppendLine(Lang.Get("pisciculture:info-generation", fishTree.GetInt("generation", 0)));
            }
            if (!juvenile)
            {
                dsc.AppendLine(Lang.Get("pisciculture:info-satiety", fishTree.GetFloat("portions", 0f).ToString("0.#"), PiscicultureSystem.MaxPortions.ToString("0.#")));
            }
            if (!juvenile && fishTree.HasAttribute("weight"))
            {
                float w = fishTree.GetFloat("weight", 0.75f);
                dsc.AppendLine(Lang.Get(w >= 0.95f ? "creature-weight-good" : w >= 0.75f ? "creature-weight-ok" : w >= 0.5f ? "creature-weight-low" : "creature-weight-starving"));
            }
            if (fishTree.GetFloat("maxhp", 0f) > 0f)
            {
                dsc.AppendLine(Lang.Get("pisciculture:info-health", fishTree.GetFloat("hp", 0f).ToString("0.#"), fishTree.GetFloat("maxhp", 0f).ToString("0.#")));
            }
        }
    }

    /// <summary>
    /// Balde com peixe: funciona como um balde comum com agua, mas guarda um peixe dentro.
    /// Pode ser colocado no chao (Shift + botao direito); o peixe continua visivel no modelo.
    /// </summary>
    public class BlockFishBucket : BlockBucket
    {
        public override ItemStack OnPickBlock(IWorldAccessor world, BlockPos pos)
        {
            ItemStack stack = base.OnPickBlock(world, pos);

            BlockEntityFishBucket be = world.BlockAccessor.GetBlockEntity(pos) as BlockEntityFishBucket;
            if (be != null && be.FishTree != null)
            {
                stack.Attributes[PiscicultureSystem.KeyBucketFish] = be.FishTree.Clone();
                if (be.BucketCode != null) stack.Attributes.SetString(PiscicultureSystem.KeyBucketCode, be.BucketCode);
            }
            return stack;
        }

        public override void GetHeldItemInfo(ItemSlot inSlot, StringBuilder dsc, IWorldAccessor world, bool withDebugInfo)
        {
            base.GetHeldItemInfo(inSlot, dsc, world, withDebugInfo);
            FishBucketInfo.Append(inSlot.Itemstack?.Attributes?.GetTreeAttribute(PiscicultureSystem.KeyBucketFish), dsc);
        }
    }

    /// <summary>
    /// Balde com peixe colocado no chao: guarda o peixe ate o balde ser recolhido.
    /// No cliente o balde e desenhado como um balde comum e o peixe e um modelo animado a parte
    /// (nada de verdade dentro do balde, com a mesma animacao de nado do peixe solto).
    /// </summary>
    public class BlockEntityFishBucket : BlockEntityBucket
    {
        public ITreeAttribute FishTree;
        public string BucketCode;

        // --- animacao (so no cliente) ---
        BlockEntityAnimationUtil animUtil;
        MeshData bucketMesh;
        bool animReady;
        float animAngleDeg = float.NaN;
        long nextBurstMs;
        long burstEndMs;
        bool bursting;

        AnimationMetaData SwimAnim;
        AnimationMetaData BurstAnim;

        public override void Initialize(ICoreAPI api)
        {
            base.Initialize(api);

            if (api.Side == EnumAppSide.Client)
            {
                SwimAnim = new AnimationMetaData() { Code = "swim", Animation = "swim", AnimationSpeed = 0.75f, EaseInSpeed = 4f, EaseOutSpeed = 4f, BlendMode = EnumAnimationBlendMode.Average }.Init();
                BurstAnim = new AnimationMetaData() { Code = "run", Animation = "run", AnimationSpeed = 1.1f, EaseInSpeed = 6f, EaseOutSpeed = 3f, BlendMode = EnumAnimationBlendMode.Average }.Init();
                animUtil = GetBehavior<BEBehaviorAnimatable>()?.animUtil;
                RebuildBucketMesh();
                SetupFish();
                nextBurstMs = api.World.ElapsedMilliseconds + 3000 + api.World.Rand.Next(6000);
                RegisterGameTickListener(OnAnimTick, 200);
            }
        }

        bool IsJuvenileBucket()
        {
            return Block != null && Block.Code.Path.Contains("juvenile");
        }

        void RebuildBucketMesh()
        {
            ICoreClientAPI capi = Api as ICoreClientAPI;
            if (capi == null) return;

            // O balde em si e o balde comum do jogo (sem o peixe do modelo estatico).
            Block plain = null;
            if (BucketCode != null) plain = capi.World.GetBlock(new AssetLocation(BucketCode));
            if (plain == null) plain = capi.World.GetBlock(new AssetLocation("game", "woodbucket"));
            BlockBucket plainBucket = plain as BlockBucket;
            if (plainBucket == null) { bucketMesh = null; return; }

            MeshData mesh = plainBucket.GenMesh(capi, GetContent(), Pos);
            if (mesh != null && mesh.CustomInts != null)
            {
                for (int n = 0; n < mesh.CustomInts.Count; n++)
                {
                    mesh.CustomInts.Values[n] |= VertexFlags.LiquidWeakWaveBitMask;
                    mesh.CustomInts.Values[n] |= VertexFlags.LiquidWeakFoamBitMask;
                }
            }
            bucketMesh = mesh;
        }

        /// <summary>Cria (ou recria, se o balde girou) o peixe animado dentro do balde.</summary>
        void SetupFish()
        {
            ICoreClientAPI capi = Api as ICoreClientAPI;
            if (capi == null || animUtil == null) return;

            float angleDeg = MeshAngle * GameMath.RAD2DEG;
            if (animReady && angleDeg == animAngleDeg) return;
            animAngleDeg = angleDeg;

            string bp = Block.Code.Path; // fishbucket-<especie>-<idade>
            string bkey = bp.Substring(11, bp.Length - 11 - (IsJuvenileBucket() ? 9 : 6));
            Shape shape = Shape.TryGet(capi, new AssetLocation("pisciculture", (IsJuvenileBucket() ? "shapes/block/fishbucket-fishj-" : "shapes/block/fishbucket-fish-") + bkey + ".json"));
            if (shape == null)
            {
                capi.World.Logger.Warning("[pisciculture] Modelo animado do peixe do balde nao encontrado.");
                return;
            }

            animUtil.InitializeAnimator("pisciculture-fishbucket-" + Pos, shape, null, new Vec3f(0, angleDeg, 0));
            if (animUtil.renderer != null)
            {
                float k = Block.Attributes != null ? Block.Attributes[IsJuvenileBucket() ? "fishScaleJuvenile" : "fishScale"].AsFloat(IsJuvenileBucket() ? 0.36f : 0.66f) : (IsJuvenileBucket() ? 0.36f : 0.66f);
                animUtil.renderer.ScaleX = k;
                animUtil.renderer.ScaleY = k;
                animUtil.renderer.ScaleZ = k;
            }
            animUtil.StartAnimation(SwimAnim);
            animReady = true;
            bursting = false;
        }

        void OnAnimTick(float dt)
        {
            if (!animReady || animUtil == null) return;
            long now = Api.World.ElapsedMilliseconds;

            // De vez em quando o peixe da uma arrancada (nado rapido) e volta a nadar devagar.
            if (!bursting && now >= nextBurstMs)
            {
                bursting = true;
                burstEndMs = now + 1600;
                animUtil.StartAnimation(BurstAnim);
            }
            else if (bursting && now >= burstEndMs)
            {
                bursting = false;
                animUtil.StopAnimation("run");
                nextBurstMs = now + 6000 + Api.World.Rand.Next(10000);
            }
        }

        public override bool OnTesselation(ITerrainMeshPool mesher, ITesselatorAPI tesselator)
        {
            if (bucketMesh != null)
            {
                mesher.AddMeshData(bucketMesh.Clone().Rotate(0, MeshAngle, 0));
                return true;
            }
            return base.OnTesselation(mesher, tesselator);
        }

        public override void OnBlockPlaced(ItemStack byItemStack = null)
        {
            base.OnBlockPlaced(byItemStack);

            ITreeAttribute tree = byItemStack?.Attributes?.GetTreeAttribute(PiscicultureSystem.KeyBucketFish);
            if (tree != null) FishTree = (ITreeAttribute)tree.Clone();
            BucketCode = byItemStack?.Attributes?.GetString(PiscicultureSystem.KeyBucketCode, null);
            if (Api != null && Api.Side == EnumAppSide.Client) { RebuildBucketMesh(); SetupFish(); }
            MarkDirty(true);
        }

        public override void ToTreeAttributes(ITreeAttribute tree)
        {
            base.ToTreeAttributes(tree);
            if (FishTree != null) tree[PiscicultureSystem.KeyBucketFish] = FishTree.Clone();
            if (BucketCode != null) tree.SetString(PiscicultureSystem.KeyBucketCode, BucketCode);
        }

        public override void FromTreeAttributes(ITreeAttribute tree, IWorldAccessor worldForResolving)
        {
            base.FromTreeAttributes(tree, worldForResolving);
            ITreeAttribute t = tree.GetTreeAttribute(PiscicultureSystem.KeyBucketFish);
            FishTree = t != null ? (ITreeAttribute)t.Clone() : null;
            BucketCode = tree.GetString(PiscicultureSystem.KeyBucketCode, null);
            if (Api != null && Api.Side == EnumAppSide.Client && animUtil != null) { RebuildBucketMesh(); SetupFish(); }
        }

        public override void GetBlockInfo(IPlayer forPlayer, StringBuilder dsc)
        {
            base.GetBlockInfo(forPlayer, dsc);
            FishBucketInfo.Append(FishTree, dsc);
        }
    }

    /// <summary>Bloco da ova: guarda especie e geracao ao ser coletado e ao ser colocado de novo.</summary>
    public class BlockFishRoe : Block
    {
        public override ItemStack[] GetDrops(IWorldAccessor world, BlockPos pos, IPlayer byPlayer, float dropQuantityMultiplier = 1f)
        {
            // Quebrar a ova na mao a destroi: so da para coletar com um balde com agua.
            return new ItemStack[0];
        }

        public override ItemStack OnPickBlock(IWorldAccessor world, BlockPos pos)
        {
            ItemStack stack = base.OnPickBlock(world, pos);
            BlockEntityTroutRoe be = world.BlockAccessor.GetBlockEntity(pos) as BlockEntityTroutRoe;
            if (be != null && stack != null)
            {
                stack.Attributes.SetString("species", be.Species);
                if (be.Generation > 0) stack.Attributes.SetInt("generation", be.Generation);
            }
            return stack;
        }

        public override void GetHeldItemInfo(ItemSlot inSlot, StringBuilder dsc, IWorldAccessor world, bool withDebugInfo)
        {
            base.GetHeldItemInfo(inSlot, dsc, world, withDebugInfo);
            // A especie e sempre a do proprio item (nome da ova); so ovas domesticadas tem geracao.
            string sp = PiscicultureSystem.RoeSpeciesOf(inSlot.Itemstack?.Block);
            dsc.AppendLine(Lang.Get("pisciculture:info-roe-species", Lang.Get("pisciculture:fish-name-" + sp)));
            int gen = inSlot.Itemstack != null ? inSlot.Itemstack.Attributes.GetInt("generation", 0) : 0;
            if (gen > 0) dsc.AppendLine(Lang.Get("pisciculture:info-generation", gen));
        }
    }

    /// <summary>
    /// Bloco de ova: eclode dentro da agua depois de alguns dias e vira filhotes de truta.
    /// </summary>
    public class BlockEntityTroutRoe : BlockEntity
    {
        double progressDays;
        double lastTickDays;
        double outHours;      // horas (do jogo) fora da agua
        int lastDryPct = -1;
        bool started;
        int lastSyncedPct = -1;

        /// <summary>Geracao dos filhotes que vao nascer desta ova (geracao da mae + 1).</summary>
        public int Generation = 0;

        /// <summary>Especie dos filhotes (ex.: "trout-rainbow").</summary>
        public string Species = PiscicultureSystem.DefaultSpecies;

        public override void OnBlockPlaced(ItemStack byItemStack = null)
        {
            base.OnBlockPlaced(byItemStack);
            if (byItemStack != null)
            {
                Species = PiscicultureSystem.RoeSpeciesOf(RB);
                Generation = byItemStack.Attributes.GetInt("generation", 0);
                MarkDirty();
            }
        }

        public override void Initialize(ICoreAPI api)
        {
            base.Initialize(api);
            if (RB != null) Species = PiscicultureSystem.RoeSpeciesOf(RB);

            if (api.Side == EnumAppSide.Server)
            {
                if (!started)
                {
                    started = true;
                    lastTickDays = api.World.Calendar.TotalDays;
                }
                RegisterGameTickListener(OnTick, 5000);
            }
            else
            {
                animUtil = new BlockEntityAnimationUtil(api, this);   // proprio: nao depende do comportamento "Animatable" do bloco
                RegisterGameTickListener(OnClientTick, 1000);
            }
        }

        BlockEntityAnimationUtil animUtil;
        bool shaking, shakeInit;

        /// <summary>O bloco de ova na camada solida (Block pode devolver a agua que o cobre).</summary>
        Block RB { get { return Api == null ? Block : Api.World.BlockAccessor.GetBlock(Pos, BlockLayersAccess.Solid); } }

        void OnClientTick(float dt)
        {
            ICoreClientAPI capi = Api as ICoreClientAPI;
            if (capi == null) return;
            Block rb = RB;
            if (!(rb is BlockFishRoe)) return;
            if (animUtil == null) animUtil = new BlockEntityAnimationUtil(Api, this);
            if (PiscicultureSystem.IsDeadRoe(rb))
            {
                if (shaking) { animUtil.StopAnimation("tremer"); shaking = false; }
                return;
            }
            double pct = progressDays / PiscicultureSystem.GetIncubationDays(Api.World);
            if (pct >= 0.5 && !shaking)
            {
                if (!shakeInit)
                {
                    string shapeName = rb.Attributes != null ? rb.Attributes["roeShape"].AsString(null) : null;
                    if (shapeName == null) { Api.Logger.Warning("[pisciculture] Ova sem roeShape: " + rb.Code); return; }
                    Shape shape = Shape.TryGet(capi, new AssetLocation("pisciculture", "shapes/block/" + shapeName.ToLowerInvariant() + ".json"));
                    if (shape == null) { Api.Logger.Warning("[pisciculture] Forma da ova nao encontrada: " + shapeName); return; }
                    animUtil.InitializeAnimator("pisciculture-roe-" + Species + "-" + Pos, shape, null, new Vec3f(0, 0, 0));
                    shakeInit = true;
                }
                animUtil.StartAnimation(new AnimationMetaData() { Code = "tremer", Animation = "tremer", AnimationSpeed = 1f, EaseInSpeed = 3f, EaseOutSpeed = 3f, BlendMode = EnumAnimationBlendMode.Average }.Init());
                shaking = true;
                Api.Logger.Debug("[pisciculture] Animacao da ova iniciada em " + Pos + " (" + (int)(pct * 100) + "%)");
            }
        }

        public override bool OnTesselation(ITerrainMeshPool mesher, ITesselatorAPI tesselator)
        {
            // enquanto o animador desenha a ova, o bloco nao desenha a forma estatica
            if (animUtil != null && shaking) return true;
            return base.OnTesselation(mesher, tesselator);
        }

        public override void OnBlockUnloaded()
        {
            base.OnBlockUnloaded();
            animUtil?.Dispose();
        }

        public override void OnBlockRemoved()
        {
            base.OnBlockRemoved();
            animUtil?.Dispose();
        }

        void OnTick(float dt)
        {
            Block rb = RB;
            if (!(rb is BlockFishRoe)) { Api.World.BlockAccessor.RemoveBlockEntity(Pos); return; }   // BE orfao: a ova ja nao existe
            double incubation = PiscicultureSystem.GetIncubationDays(Api.World);
            double now = Api.World.Calendar.TotalDays;
            double elapsed = now - lastTickDays;
            lastTickDays = now;
            if (elapsed < 0) elapsed = 0;

            double elapsedHours = elapsed * 24.0;
            bool dead = PiscicultureSystem.IsDeadRoe(rb);
            Block fluid = Api.World.BlockAccessor.GetBlock(Pos, BlockLayersAccess.Fluid);
            bool inWater = fluid != null && fluid.LiquidCode == "water";

            if (dead)
            {
                // Ova morta nunca eclode; apodrece 24 h depois de sair da agua.
                outHours += elapsedHours;
                if (outHours >= PiscicultureSystem.RoeRotHours) Rot();
                return;
            }

            if (!inWater)
            {
                // Fora da agua a ova nao evolui e vai secando: 1 h e ela morre.
                outHours += elapsedHours;
                if (outHours >= PiscicultureSystem.RoeDryDeathHours) { Die(); return; }
                int dpct = (int)(outHours / PiscicultureSystem.RoeDryDeathHours * 100);
                if (dpct / 5 != lastDryPct / 5) { lastDryPct = dpct; MarkDirty(); }
                return;
            }
            if (outHours > 0) { outHours = 0; lastDryPct = -1; MarkDirty(); }

            progressDays += elapsed;

            // Avisa os jogadores do novo progresso (sem isso a tela mostraria sempre o mesmo valor).
            int pct = (int)Math.Min(100, progressDays / incubation * 100);
            if (pct != lastSyncedPct)
            {
                lastSyncedPct = pct;
                MarkDirty();
            }

            if (progressDays < incubation) return;

            Hatch();
        }

        /// <summary>A ova seca e morre: troca para a variante esbranquicada (mantem especie e geracao).</summary>
        void Die()
        {
            string path = RB.Code.Path;
            string last = path.Substring(path.LastIndexOf('-') + 1);
            Block dead = Api.World.GetBlock(new AssetLocation("pisciculture", path.Substring(0, path.LastIndexOf('-') + 1) + "d" + last));
            if (dead == null) { Api.Logger.Warning("[pisciculture] Variante morta da ova nao encontrada para " + path); return; }
            Api.World.BlockAccessor.ExchangeBlock(dead.Id, Pos);
            MarkDirty(true);
        }

        /// <summary>Mais de 24 h fora da agua: a ova morta vira restos podres (item "rot" do jogo, equivalente a 1 L) no chao.</summary>
        void Rot()
        {
            Item rot = Api.World.GetItem(new AssetLocation("game", "rot"));
            Api.World.BlockAccessor.SetBlock(0, Pos, BlockLayersAccess.Solid);
            Api.World.BlockAccessor.RemoveBlockEntity(Pos);
            if (rot != null) Api.World.SpawnItemEntity(new ItemStack(rot, 1), new Vec3d(Pos.X + 0.5, Pos.Y + 0.1, Pos.Z + 0.5));
        }

        void Hatch()
        {
            Vec3d center = new Vec3d(Pos.X + 0.5, Pos.Y + 0.5, Pos.Z + 0.5);

            Entity[] nearby = Api.World.GetEntitiesAround(center, 16, 8, e => e.Alive && PiscicultureSystem.IsAnyTrout(e));
            if (nearby.Length >= PiscicultureSystem.MaxTroutNearRoe) return;

            EntityProperties type = Api.World.GetEntityType(new AssetLocation("pisciculture", "fish-" + PiscicultureSystem.NormalizeSpecies(Species) + "-juvenile"));
            if (type == null)
            {
                Api.Logger.Warning("[pisciculture] Tipo de entidade do filhote nao encontrado; a ova nao pode eclodir.");
                return;
            }

            // Peixes pequenos: 2 alevinos por ova; peixes grandes: so 1. A chance de nascer mais um sobe 10% a cada geracao (100% na geracao 10).
            int baseCount = PiscicultureSystem.BigFishSpecies.Contains(PiscicultureSystem.NormalizeSpecies(Species)) ? 1 : 2;
            int count = baseCount + (Api.World.Rand.NextDouble() < Math.Min(1.0, 0.1 * Math.Max(1, Generation)) ? 1 : 0);
            for (int i = 0; i < count; i++)
            {
                Entity fish = Api.World.ClassRegistry.CreateEntity(type);
                fish.Pos.SetPos(Pos.X + 0.5 + (Api.World.Rand.NextDouble() - 0.5) * 0.4, Pos.Y + 0.4, Pos.Z + 0.5 + (Api.World.Rand.NextDouble() - 0.5) * 0.4);
                fish.Pos.Yaw = (float)(Api.World.Rand.NextDouble() * Math.PI * 2);
                fish.WatchedAttributes.SetInt("generation", Math.Max(1, Generation));
                Api.World.SpawnEntity(fish);
            }

            Api.Logger.Debug("[pisciculture] Ova eclodiu em " + Pos + " (" + count + " filhote(s)).");
            Api.World.BlockAccessor.SetBlock(0, Pos, BlockLayersAccess.Solid);
            Api.World.BlockAccessor.RemoveBlockEntity(Pos);
        }

        public override void ToTreeAttributes(ITreeAttribute tree)
        {
            base.ToTreeAttributes(tree);
            tree.SetDouble("progressDays", progressDays);
            tree.SetDouble("lastTickDays", lastTickDays);
            tree.SetBool("started", started);
            tree.SetInt("generation", Generation);
            tree.SetString("species", Species);
            tree.SetDouble("outHours", outHours);
        }

        public override void FromTreeAttributes(ITreeAttribute tree, IWorldAccessor worldAccessForResolve)
        {
            base.FromTreeAttributes(tree, worldAccessForResolve);
            progressDays = tree.GetDouble("progressDays", 0);
            lastTickDays = tree.GetDouble("lastTickDays", 0);
            started = tree.GetBool("started", false);
            Generation = tree.GetInt("generation", 0);
            Species = PiscicultureSystem.NormalizeSpecies(tree.GetString("species", PiscicultureSystem.DefaultSpecies));
            outHours = tree.GetDouble("outHours", 0);
        }

        public override void GetBlockInfo(IPlayer forPlayer, StringBuilder dsc)
        {
            base.GetBlockInfo(forPlayer, dsc);

            int pct = (int)Math.Min(100, progressDays / PiscicultureSystem.GetIncubationDays(Api.World) * 100);
            dsc.AppendLine(Lang.Get("pisciculture:info-roe-species", Lang.Get("pisciculture:fish-name-" + Species)));
            if (Generation > 0) dsc.AppendLine(Lang.Get("pisciculture:info-generation", Generation));
            if (PiscicultureSystem.IsDeadRoe(RB))
            {
                dsc.AppendLine(Lang.Get("pisciculture:info-roe-dead"));
                return;
            }
            if (outHours > 0) dsc.AppendLine(Lang.Get("pisciculture:info-roe-drying", (int)Math.Min(100, outHours / PiscicultureSystem.RoeDryDeathHours * 100)));
            dsc.AppendLine(Lang.Get("pisciculture:roe-progress", pct));
        }
    }
}
