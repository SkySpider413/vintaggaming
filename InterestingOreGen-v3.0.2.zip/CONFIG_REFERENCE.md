# Interesting Ore Gen configuration reference

The live file is `VintagestoryData/ModConfig/interestingoregen/config.json`. IOG creates it on first load and rewrites the loaded object with `LoadModConfig<IOGConfig>` / `StoreModConfig`. Use [config.example.jsonc](config.example.jsonc) as a **commented reference**; keep the live file as ordinary JSON. The object serialization used for configuration does not retain comments across save/reload, even though Newtonsoft can parse them. The example is tested against every current default value. Unknown JSON properties are not represented in the typed configuration object and should not be relied upon.

**World safety:** ordinary production records a generation identity in the save. Changing production controls, family weights, material policy, indicator toggles, registered blocks, or algorithm versions can make an existing world's identity mismatch. IOG then refuses further normal generation in that world. Use a fresh world for such changes. Already generated chunks are not rewritten. Development trials are for disposable worlds and exclude normal production while active.

## Normal generation

| Setting | Default | Meaning and supported values |
| --- | --- | --- |
| `ConfigVersion` | `3.2` | File schema marker. IOG rewrites it to the current value on migration; it is not a gameplay option. |
| `ProductionWorldgenEnabled` | `true` | Enables the normal ore generator. `false` disables it, without deleting ore already in the world. Affects production identity. |
| `ProductionMinimumSeedDistance` | `200` | Minimum horizontal separation, in blocks, between deterministic **seed sites**. Must be at least 1. Deposits can extend past their sites and overlap in space. Changing it changes world generation identity and candidate density. |
| `ProductionSiteAcceptance` | `1.0` | Probability from 0 to 1 that a lattice site proceeds to family selection. `0` accepts none; `1` tests every site. Geological and material rejection still occur afterward. Affects identity and generation workload. |
| `ProductionFamilyWeights` | `0.5 / 0.5 / 0.5 / 0.5 / 0.5` | Relative selection weights for Hydrotube, Fault, Seam, Chimney and Blob Cluster in that order. Nonnegative finite numbers; `0` disables a family. An explicit partial or empty map stays limited. Affects identity. |
| `ProductionWorldgenDiagnosticsEnabled` | `false` | Bounded candidate, timing, cache and column logs. Can increase logging overhead; intended for diagnosis, not ore balancing. |
| `GlobalOreDisableChance` | `0.0` | Legacy tilted-disc generator attempt suppression. It is **not** the normal five-family production frequency control. |

The default family weights sum to **2.5**. Each family receives **20%** of selected family outcomes before eligibility. A selected site can be rejected for unavailable geology, no legal registered primary, bounds, or other safeguards. Weights therefore do not guarantee deposits, ore volume, or ore of a given material. All five families use the same 200-block default seed lattice and can span many 32-block columns. Registered host variants and material/geology restrictions still decide which blocks can be placed. A deposit may disappear in an incompatible stratum and resume in a compatible one.

- **Hydrotube:** hydrothermal tube-like network.
- **Fault:** fault sheets and fracture-related mineralization.
- **Seam:** broad sheet-like deposit following eligible strata.
- **Chimney:** branching rooted chimney and stockwork.
- **Blob Cluster:** many small irregular ore pockets joined by narrow mineralized passages.

`ProductionFamilyWeights` migration recognizes the complete prior five-family default map (`1 / 1 / 0.5 / 0.5 / 1`) and converts it to five `0.5` values. A complete older four-family default first gains Blob; an older version-marked complete three-family default first gains Chimney and Blob, then both convert to the new defaults. Custom, partial, empty and zero-weight maps are preserved. A user who deliberately chose values identical to the prior complete defaults is indistinguishable from an untouched default and will also migrate. The schema marker remains 3.2.

## Prospecting

| Setting | Default | Effect |
| --- | --- | --- |
| `depositIndicatorBoulder` | `true` | Enables shared mineral indicator boulders where suitable natural surfaces and registered outputs exist. |
| `depositIndicatorProspectVeins` | `true` | Enables shared underground mineralized tracer veins and their eligible packed-dirt or dirty-gravel surface clues. |

These settings are independent and do **not** disable the underlying ore bodies. Indicators can be absent because of depth, terrain, incompatible source rock, water, vegetation, protected structures, or missing registered output. Tracer ore resolves against the actual original host for Blob Clusters. Changing either toggle affects production identity and future virgin terrain only.

## Material roles and geology

The material ID is the registered namespace-qualified ore material, such as `game:hematite`; block codes are different. Primary selection occurs at a site's geological anchor. A primary stays fixed throughout its deposit. Secondary selection is separate. Each output position uses the **original natural source host** and only a registered material/host variant and available grade ceiling. Some families use parent-rock-specific policies; the Blob Cluster keeps original-host source rock throughout. No config rule can create an unregistered ore block.

| Setting | Default | Meaning |
| --- | --- | --- |
| `MaterialSelection.GemstonesSecondaryOnly` | `true` | Recognized/declared gemstones cannot be primary unless changed. |
| `MaterialSelection.GemstoneMaterialIds` | `[]` | Exact IDs to additionally classify as gemstones; supplement recognized vanilla gems and registered metadata. Unknown mod ores are not guessed by name. |
| `MaterialSelection.SecondaryOnlyMaterialIds` | 21 listed IDs, including `game:borax` | Excludes these materials from primary use while allowing legal secondary use. The full default list is in the commented example. `[]` deliberately removes the built-in list. Borax is **not disabled**: it can appear as a secondary where registered hosts and other material rules allow it. |
| `MaterialSelection.DisabledMaterialIds` | `["game:flint"]` | Removes a material from both roles. `[]` removes this default exclusion. |
| `MaterialSelection.AllowedFamiliesByMaterialId` | Four coal IDs limited to `iog:seam` | Exact material ID to allowed family IDs. `{}` removes the default coal restriction. An empty family list excludes that material from all families. |
| `MaterialGeologyRules` | `[]` | Optional per-material role, family, host and category overrides; see fields below. No entry means no extra per-material geology rule. |

Default `game:` role entries also cover an equivalent material type registered under another namespace; explicit `mod:` entries can be added independently. Disabling a material removes both roles; secondary-only removes the primary role; family permission limits deposit families; geological restrictions limit categories or source host codes. These are separate filters and compose with registered block availability. Policy changes alter production identity. Current source applies the same restrictions to Blob primary/secondary selection and tracer output.

New and missing secondary-only lists include `game:borax`. Existing saved lists, including the prior 20-ID generated roster, remain as written: the loader cannot distinguish that prior roster from a deliberate choice to omit Borax. Add `game:borax` to an existing list to apply the new restriction. Removing it from a new list permits Borax as a primary where every other registration and policy check permits it.
Secondary-only is a role permission, not a guarantee of selection. Seams retain their established associated-material rules: a nonstandard Seam secondary, including Borax, needs an explicit eligible Seam material rule. Other families can select registered Borax as a secondary under their existing secondary policy.

Each `MaterialGeologyRules` item accepts the following fields. The default values shown are defaults **within a new rule**; the list itself is empty by default.

| Rule field | Default | Meaning |
| --- | --- | --- |
| `MaterialId` | `""` | Required namespace-qualified registered material ID. Duplicate/empty IDs are invalid. |
| `AllowedCategories` | `[]` | Restrict to `sediment`, `bedrock`, `sedimentary`, `metamorphic`, `igneous_intrusive`, or `igneous_extrusive`. Empty means no added category restriction. |
| `AllowedFamilies` | `[]` | Restrict to named IOG family IDs; empty means no added family restriction. |
| `SourceHostCodes` | `[]` | Namespace-qualified natural source block codes allowed for this material. Empty means no added host-code restriction. |
| `Primary`, `Secondary` | `true`, `true` | Permit this material in each role. Other global role restrictions still apply. |
| `DirectBlockCode` | `""` | Explicit registered direct output for non-rock-hosted material rules, especially associated Seam underlayers. Empty uses registered ore variants. It does not synthesize a rock-hosted ore variant. |
| `Weight` | `1.0` | Nonnegative finite selection weight for this material where applicable; `0` removes it from weighted selection. |

## Secondary mineralization

`SecondaryOres` applies only after a legal primary is chosen. It cannot override disabled materials, forbidden complete sets, source-host registration, or family/geology restrictions. Its controls affect production identity. Weights are relative and have no physical unit.

| Setting | Default | Meaning |
| --- | --- | --- |
| `Enabled` | `true` | `false` suppresses optional secondaries. |
| `ZeroWeight`, `OneWeight`, `TwoWeight` | `20`, `55`, `25` | Relative weights for requesting 0, 1 or 2 legal secondaries. If only one is available, the two-material weight folds into one. Zero removes an outcome's weight. |
| `DefaultMaterialWeight` | `1` | Relative weight of otherwise eligible secondary material IDs without an explicit entry. |
| `MaterialWeights` | `{}` | ID-specific relative overrides; zero excludes that secondary from selection. |
| `AllowedByPrimary` | `{}` | Primary ID to allowed secondary IDs. Where a key exists, unlisted secondaries are excluded. |
| `DeniedByPrimary` | `{}` | Primary ID to denied secondary IDs. |
| `ForbiddenSets` | `[["copper","tin"],["copper","bismuth","zinc"]]` | Canonical complete-set exclusions. These defaults prevent the listed combinations; `[]` deliberately removes them. |
| `ZoneScale` | `1` | Multiplier in the Hydrotube secondary-zone construction and part of secondary policy identity. Use positive finite values for meaningful zones. |

`AllowedByPrimary` and `DeniedByPrimary` are directional. `ForbiddenSets` tests the complete primary plus secondary set using the code's canonical ore aliases. A selected secondary may be skipped in an incompatible source host; Blob placement falls back to legal primary there. Gemstone potential grades and ungraded outputs use only registered variants.

## Seams and associated underlayers

| Setting | Default | Meaning |
| --- | --- | --- |
| `SeamAllowIgneousHosts` | `false` | Sedimentary and metamorphic hosts are enabled by default; this adds igneous intrusive and extrusive hosts where outputs are legal. |
| `SeamUnderlayers.Mode` | `"AlwaysWhenEligible"` | `AlwaysWhenEligible`, `Optional`, or `Disabled`. Controls whether a legal associated underlayer is attempted. |
| `SeamUnderlayers.OptionalChance` | `0.5` | Probability from 0 to 1 used only when mode is `Optional`; zero suppresses optional attempts. |
| `SeamUnderlayers.AllowSubstantial` | `false` | Allows seeded substantial underlayers when an associated output is eligible; default underlayers remain thin. |
| `SeamUnderlayers.CoalMaterials` | `["game:fireclay"]` | Direct registered materials to try beneath coal Seams. Empty removes automatic coal association. |
| `SeamUnderlayers.SedimentaryMaterials` | `["interestingoregen:saltpeterore"]` | Legacy option name: direct registered materials to try beneath non-coal Seams in any registered natural stone, including a secondary layer whose category is disabled for primary Seam selection. Empty removes automatic association. Each original stone block still requires a valid registered source. |

The defaults attempt **thin, patchy fireclay under coal Seams** and **thin, patchy saltpeter under other sedimentary-hosted Seams**, subject to registered direct-block rules and actual source eligibility. Metamorphic and igneous primaries do not automatically receive these underlayers. Mode, chance, output lists and host option affect production identity. An associated material's selection does not invent a host-rock ore variant.

## Development and diagnostics

All `Development` placement trial switches default to `false`. They are for disposable worlds; an enabled placement trial excludes ordinary production. Trial site strings use `cellX:cellZ` deterministic lattice coordinates when supported, and `""` invokes the trial's automatic search. Optional primary IDs require exact registered namespace-qualified materials. Trial identity is separate from production identity.

| `Development` setting | Default | Meaning |
| --- | --- | --- |
| `FoundationDiagnosticsEnabled` | `true` | Registry and foundation diagnostic logging in this development build. It does not directly place ore. |
| `FoundationTestPlacementEnabled` | `false` | Older controlled placement trial; disposable world only. |
| `FoundationTestSite` | `""` | Explicit site for the older placement trial; empty selects its automatic mode. |
| `FoundationTestThickness` | `0.05` | Experimental geological threshold fraction; accepted values are `0.03` or `0.05`. |
| `FoundationTestAutoCount` | `3` | Automatic test site count, 0–10. Zero disables automatic writes. |
| `FoundationPlanningProbeEnabled` | `false` | Read-only planning lifecycle probe. |
| `FoundationPlanningProbeColumnLimit` | `2048` | Bounded callback sample count, clamped to 1–8192. |
| `FoundationGeologicalPlanningProbeEnabled` | `false` | Read-only detached geology probe. |
| `FoundationGeologicalPlanningProbeColumnLimit` | `2048` | Bounded geology sample count, clamped to 1–8192. |
| `FoundationCrossColumnTrialEnabled` | `false` | Cross-column placement trial. |
| `FoundationHydrotubeTrialEnabled` | `false` | One-site Hydrotube placement trial. |
| `FoundationFaultTrialEnabled` | `false` | One-site Fault placement trial. |
| `FoundationFaultTrialSite` | `""` | Optional Fault lattice cell. |
| `FoundationSeamTrialEnabled` | `false` | One-site Seam placement trial. |
| `FoundationSeamTrialSite` | `""` | Optional Seam lattice cell. |
| `FoundationSeamTrialPrimaryMaterial` | `""` | Optional exact registered primary material for the Seam trial. |
| `FoundationChimneyTrialEnabled` | `false` | One-site Chimney placement trial. |
| `FoundationChimneyTrialSite` | `""` | Optional Chimney lattice cell. |
| `FoundationBlobClusterTrialEnabled` | `false` | One-site Blob Cluster placement trial. |
| `FoundationBlobClusterTrialSite` | `""` | Optional Blob lattice cell. |
| `FoundationBlobClusterTrialPrimaryMaterial` | `""` | Optional exact registered primary material for the Blob trial. |
| `ExperimentalCaveInsEnabled` | `false` | Reserved and currently inert. The Phase 1E field model is read-only; setting this to `true` does not enable cave-ins. |
| `EnhancedCaveInsEnabled` | `true` | Restart-gated IOG ownership of Vanilla unstable-rock cave-ins. Set `false` for Vanilla rock-collapse ownership. Enables compact structural evaluation, event-driven persistent damage, brief physical spalling and delayed layered cave-ins. |
| `CaveInBalance` | See table below | Restart-gated bounds and timings for the enhanced cave-in owner. Ignored when `EnhancedCaveInsEnabled` is false. |
| `StructuralStonePillarCodes` | `[]` | Exact resolved full-cube stone/brick block codes eligible as constructed pillars. The `iogStructuralStonePillar` asset attribute is also accepted; footing remains mandatory. |
| `StructuralBlockProfiles`, `StructuralHostProfiles`, `StructuralGroupProfiles` | `{}` | Optional complete Phase 1E diagnostic material profiles keyed by exact block code, registered host code, or geological group. These affect the read-only field diagnostic only. |
| `StructuralBlockProfiles[*].BendingFactor` | `0.5` | Optional full-log bending load coefficient in an overridden material profile (0–4). Higher values reduce sustainable long-span Beam delivery and localize more physical member stress. |
| `StructuralDepthAtMaximum` | `156` | Local terrain-relative depth where read-only field roof demand reaches its cap. |
| `StructuralMaximumDepthMultiplier` | `6` | Maximum read-only field roof demand multiplier; does not multiply damage or shock. |
| `ExperimentalFieldTrackingEnabled` | `false` | Legacy numerical-only field tracker, automatically inactive when `EnhancedCaveInsEnabled` is true. |
| `FieldTrackingDebounceMilliseconds` | `1500` | Optional early quiet-time assessment of dirty areas; clamped to 500–5000 ms. Continuous edits do not postpone the regular deadline. |
| `FieldTrackingPeriodicMilliseconds` | `10000` | Approximate regular deadline for a dirty area's first assessment; clamped to 2000–60000 ms. Capture and solving may finish later. |
| `FieldTrackingCaptureRadius` | `20` | Horizontal half-width of bounded immutable capture; clamped to 8–32 blocks. An assessment that needs geometry beyond it is unresolved. |
| `StructuralFullLogAxes` | `{}` | Exact resolved modded full-cube log code to longitudinal axis (`x`, `y`, or `z`). Vanilla full logs and debarked full logs use verified `rotation` variants automatically. |

Diagnostic/probe limits control logging or measurement cost. Placement trials can write temporary test ore and carry their own save identity; do not enable them in a valued world. Changing development flags does not retroactively update terrain.

## Cave-ins

`Development.EnhancedCaveInsEnabled` is the feature switch. Change it only while the game is stopped. Its default is `true`; an explicit `false` in an existing config remains effective and leaves Vanilla's configured rock-collapse behavior available. With it `true`, IOG sets loaded `BlockBehaviorUnstableRock.CaveIns` flags to false and verifies exclusive ownership; Vanilla sand, gravel and other falling-block behavior is untouched. IOG then evaluates local supports and persistent event-driven damage, and can produce bounded physical spalling or delayed layered cave-ins after fresh world checks. `/iogstruct inspectstability`, `/iogstruct reportstability`, and `/iogstruct stabilitystatus` show current local evidence, pending failures and ownership. If ownership or registered rock evidence cannot be verified, the mode reports blocked rather than armed. World-level `caveIns` and `allowFallingBlocks` settings are not rewritten. Disabling the Vanilla unstable-rock behavior also disables its own placed-block instability text and chiseling restriction on the server; IOG provides a separate targeted block-info readout, while chiseling parity is deferred.

Damage accumulates after completed mining or blast events when current instability exceeds the configured threshold. By default it falls linearly from 0.80 at zero continuous solid overhead blocks to 0.20 at 100. Placing support does not erase saved damage. Missing evidence suspends damage and physical failure. Saved damage remains under `iog-structural-damage-v1`; pending major failures retain their absolute game-hour deadline under `iog-structural-failures-v1` when delay settings change. Targeted rock information is requested from the server at most twice per second while the tooltip is open. Vanilla chiseling parity remains deferred.

`Development.ExperimentalCaveInsEnabled` remains inert. The old immediate IOG break and placed-block Harmony patches are retired. `Development.ExperimentalFieldTrackingEnabled` can run the legacy numerical prototype outside enhanced mode; it never starts in enhanced mode. The old `/iogstruct inspectfield`, `/iogstruct reportfield`, and `/iogstruct fieldstatus` commands remain legacy, read-only diagnostics. Each enhanced assessment reads the current placed-beam block entities, so beam addition/removal affects the next targeted readout and physical revalidation without a persistent support cache. Ordinary edits enqueue bounded local reassessments; beam-only edits do not initiate a new damage event.

Vanilla full `log` and `debarkedlog` blocks are recognized by their resolved `ud`/`we`/`ns` rotation and full collision cube. Other full logs require `iogStructuralFullLog` plus a verified `iogStructuralLogAxis` asset attribute or an exact entry in `StructuralFullLogAxes`; generic wood and partial logs are ineligible. A full log contributes only after grounded Post or two-contact Beam geometry validates. Vanilla thin placed beams are interpreted from their live block-entity segments, bounded to their actual geometry and grounded or connected mounting points. No support quantity is consumed per roof block. Field material overrides are complete profiles for the inactive numerical field only.

### `Development.CaveInBalance`

All entries below are JSON properties inside `Development.CaveInBalance`, are validated at load, and **require a server restart**. An invalid value or combination preserves the user's file, falls back to safe defaults and does not arm enhanced cave-ins for that load. Ranges are inclusive. The hard current-world, loaded-evidence, deduplication and mutation ceilings cannot be disabled.

Major initiation still requires accumulated damage in a connected ceiling. Once its first damaged cells fall, an active failure can spread through newly exposed face-connected rock with fresh instability strictly above `MajorPropagationMinimumInstability`, even without saved damage. Adequate natural or placed support stops the advancing edge. Radius, per-layer, layer-count and total limits are maximums rather than guaranteed collapse sizes. The server checks at most 12 frontier candidates and detaches at most six blocks per tick; larger configured footprints can extend a collapse across more ticks. Existing config files with explicit old values retain them until edited and the server restarted.

| Property | Type; default; allowed range | Units and effect |
| --- | --- | --- |
| `OriginalTwoSupportDistance` | number; 3; 1–12 | Blocks; game rocks in Vanilla's original distance-2 group. |
| `OriginalFourSupportDistance` | number; 4; 1–12 | Blocks; original distance-4 group. |
| `OriginalSixSupportDistance` | number; 5; 1–12 | Blocks; original distance-6 wildcard group. |
| `VerticalStoneTransfer` | integer; 4; 2–6 | Blocks; maximum vertical full-face rock transfer from a grounded origin. Horizontal search remains bounded to six blocks. |
| `ThinBeamMaximumLength` | integer; 20; 1–20 | Blocks; accepted Vanilla placed segment length, at most the installed placement cap. |
| `ThinBeamContactTolerance` | number; 0.125; 0.025–0.25 | Blocks; segment-to-rock and beam-junction geometry tolerance. |
| `ThinBeamConnectionDepth` | integer; 2; 0–3 | Links; bounded rounds of beam connections from already grounded members. Zero permits only independently valid segments. |
| `MinimumDamageInstability` | number; 0.8; 0.05–0.99 | Fraction; minimum instability for damage under zero overhead. Must be at least the deep value. |
| `MaximumDepthDamageInstability` | number; 0.2; 0.05–0.99 | Fraction; damage threshold at/after overhead saturation. |
| `OverheadSaturationBlocks` | integer; 100; 1–200 | Solid overhead blocks to scan before the threshold reaches its deep value. Missing cells suspend the result. |
| `OrdinaryBreakDamage` | number; 0.1; 0.001–1 | Fraction; base increment at full qualifying instability before event severity. |
| `MaximumEventSeverity` | number; 4; 1–4 | Multiplier ceiling for accepted damage events. Higher submitted events are rejected. |
| `EventHorizontalRadius` | integer; 2; 1–4 | Blocks; ordinary mining-event damage candidate radius. Completed blast payloads carry their own bounded radius. |
| `EventVerticalReach` | integer; 5; 1–8 | Blocks above an ordinary mining event to consider for damage. |
| `CrackingDamageStage` | number; 0.25; 0.05–0.8 | Damage fraction for cracking readout/warnings. Must precede later stages. |
| `FracturedDamageStage` | number; 0.5; 0.1–0.9 | Damage fraction for fractured stage; strictly above cracking. |
| `SevereDamageStage` | number; 0.75; 0.2–0.99 | Damage fraction for severe stage; strictly above fractured. Failure-ready remains fixed at 1.0. |
| `StructuralDamageOverlayEnabled` | boolean; true | Client-only cosmetic Vanilla crack overlays for saved damage. Requires a client restart; does not change mining or cave-in behavior. |
| `StructuralDamageOverlayDistance` | integer; 48; 16–96 | Client-only maximum display and nearby snapshot radius in blocks. Requires a client restart. At most 128 damaged blocks are drawn at once. |
| `WarningRateLimitMilliseconds` | integer; 10000; 1000–60000 | Real milliseconds between repeated warnings at the same block without a new stage transition. |
| `SpallDamageThreshold` | number; 0.75; 0.1–1 | Saved damage needed to schedule/revalidate a spall. |
| `MajorDamageThreshold` | number; 0.65; 0.1–1 | Saved damage needed in a connected major roof; cannot exceed the spall threshold. |
| `MaximumSpallBlocks` | integer; 3; 1–8 | Maximum roof cells in one spall footprint. |
| `SpallDelayMilliseconds` | integer; 1800; 100–10000 | Real milliseconds from spall scheduling to its first physical check. |
| `MinimumMajorCeilingBlocks` | integer; 3; 2–8 | Connected eligible ceiling cells required for a major event. Cannot exceed the per-layer cap. |
| `MajorHorizontalRadius` | integer; 7; 1–12 | Blocks from the major origin; damaged-roof initiation and connected physical propagation stay within this circular horizontal footprint. |
| `MinimumMajorDelayHours` | number; 0.5; 0.05–48 | In-game hours; danger-weighted minimum delay for a newly scheduled major event. |
| `MaximumMajorDelayHours` | number; 4; 0.05–48 | In-game hours; danger-weighted maximum, at least the minimum. |
| `MaximumMajorBlocksPerLayer` | integer; 48; minimum ceiling count–96 | Maximum detached blocks in one layer. |
| `MaximumMajorLayers` | integer; 5; 1–8 | Maximum successive vertical layers of an active major event. |
| `MaximumMajorBlocksTotal` | integer; 200; per-layer cap–400 | Maximum detached blocks across all layers. |
| `MajorPropagationMinimumInstability` | number; 0.20; 0–0.99 | Strict lower bound for fresh instability of exposed, connected rock joining an active major collapse; saved damage is not required for propagation. |
| `MajorLayerIntervalMilliseconds` | integer; 1100; 100–10000 | Real milliseconds between completed physical layers. |
| `MaximumConcurrentMajorFailures` | integer; 2; 1–4 | Simultaneously active major collapses. |
| `DueMajorWarningMilliseconds` | integer; 2000; 500–10000 | Real milliseconds of loaded-world warning after a major deadline becomes due or a pending major is restored. |

Game rocks follow the installed `rock.json` groups by exact code: claystone, sandstone, shale, conglomerate, limestone, chert and chalk were distance 2; bauxite, slate and phyllite were distance 4; other `game:rock-*` variants were distance 6. IOG changes only these game rock behaviors in enhanced mode. It leaves other namespaces' resolved values intact, including explicit modded settings. The adjacent IME asset patch may provide its own values before IOG starts; IOG's enhanced runtime pass is the final authority for game rocks. Outside enhanced mode, IOG does not change the values.

The self-contained [Cave-In System Reference](Foundation/CAVEIN_SYSTEM_REFERENCE.md) explains gameplay, examples and troubleshooting.

## Configuration file behavior

`IOGConfig.MigrateLoaded` fills missing grouped objects and recognized legacy family defaults, then stores schema version 3.2. Newtonsoft `ObjectCreationHandling.Replace` preserves explicit empty material lists and maps, secondary forbidden sets, and family maps on JSON load. The loader rewrites a typed object with `StoreModConfig`, so inline comments and unknown fields should be expected to disappear on rewrite. Generation settings affect **future virgin generation only**; cave-in settings take effect after restart, and saved major deadlines retain their absolute game-hour value. Production generation identity changes can require a new world.
