# Ventilation Dynamics server settings

File: `ModConfig/ventilationdynamics.json` in the server's data folder (for single player, `VintagestoryData/ModConfig`). Created with the defaults the first time the mod runs. Edit it with the server stopped, then start again. Missing settings are added back with their defaults; values out of range are pulled back into range. If the file can't be read, the mod logs an error and uses the defaults for that session.

With **Integrated Mod Manager** installed, every setting here can also be changed in game, with labels and descriptions; changes apply right away, except `AsphyxiaIntegration`, which needs a server restart. Players see new haze and fog thresholds after rejoining.

Gas density runs from 0 to 255.

## General
| Setting | Default | What it does |
|---|---|---|
| `DeathMessages` | `true` | Custom death messages for chokedamp and firedamp deaths |
| `DuctCrawling` | `true` | Sneak and use a duct run to crawl through it |
| `CrawlSecondsPerSection` | `0.25` | Crawl time per duct section (between 1 and 20 seconds in total) |

## Breathing and warnings
| Setting | Default | What it does |
|---|---|---|
| `SuffocateAt` | `64` | Chokedamp density you can't breathe |
| `TorchDimAt` | `24` | Torches, oil lamps and lanterns dim from here |
| `TorchOutAt` | `56` | Torches go out from here |
| `MaskAirMultiplier` | `1.5` | How much longer your air lasts with a breathing mask |
| `HoodRange` | `8` | Blocks from a fresh-air vent the air-hose hood works within |
| `BladderRefillPerSecond` | `2` | Seconds of air an air bladder regains per second in clean air |

## Creatures
| Setting | Default | What it does |
|---|---|---|
| `CreaturesSuffocate` | `true` | Animals use up their air in bad air like players; rust creatures (drifters, bowtorns, shivers) choke in it. Mechanical creatures are immune. |
| `AnimalsAvoidGas` | `true` | Breathing animals smell bad air from the light-dimming level and move away from it |
| `RustCreatureSuffocationDelay` | `10` | Seconds a rust creature lasts in unbreathable air before taking damage |
| `RustCreatureSuffocationDamage` | `1` | Damage per second to rust creatures after that |
| `CreatureCheckRadius` | `48` | Blocks around players where creatures react to gas |
| `GasImmuneCreatureTags` | `["mechanical", "inanimate", "vehicle", "boss"]` | Creatures with any of these tags ignore gas entirely (file only, not in Integrated Mod Manager) |

## Firedamp
| Setting | Default | What it does |
|---|---|---|
| `FiredampBurnsFrom` | `40` | Lower edge of the explosive range |
| `FiredampTooRichFrom` | `150` | Too rich to burn, and unbreathable, from here |
| `FlashFireBelowTotal` | `600` | Ignitions with less gas in total only flash; more explode |
| `FlashFireDamage` | `3` | Fire damage to anyone caught in a flash |
| `BlastRadiusMin`, `BlastRadiusMax` | `3`, `12` | Explosion size range |
| `DefaultBlastMode` | `"full"` | `full`, `crater`, `creatures` or `flash`, for worlds that haven't set one with `/vent blast` |

## Gas sources
Worlds can also switch these with `/vent sources`; the settings are the defaults for worlds that haven't.

| Setting | Default | What it does |
|---|---|---|
| `CoalFiredamp` | `true` | Mining coal releases firedamp |
| `CoalFiredampMin`, `CoalFiredampMax` | `20`, `35` | Firedamp released per coal block |
| `StaleAir` | `true` | Enclosed deep space gathers chokedamp |
| `StaleAirDepthBelowSeaLevel` | `16` | Depth below sea level where stale air starts |
| `StaleAirBuildPerCheck` | `2` | Added every 5 seconds to sampled cells near players |
| `StaleAirMax` | `100` | Stale air stops building at this density |
| `StaleAirOnArrivalMax` | `60` | Most chokedamp already present in deep cells the first time a chunk is visited |

## Drafts and ventilation
| Setting | Default | What it does |
|---|---|---|
| `DraftMinHeight` | `4` | Blocks of height difference needed for a draft |
| `DraftFullHeight` | `32` | Height difference giving a full-strength draft |
| `DraftFullLength` | `32` | Route length (in 2-block cells) before friction weakens a draft |
| `DraftCarryMax` | `1.0` | Share of a cell's gas carried along per step at full strength |
| `MineTemperatureC` | `10` | Natural drafts follow the outside temperature against this |
| `ClimateStillAirWithinC` | `2` | Within this many degrees of the mine's temperature, no natural draft (heat, scoops and extractors still work) |
| `FurnaceDrawBlocks` | `24` | A lit ventilation furnace counts as this much extra height |
| `FurnaceMaxBurnMinutes` | `60` | Most fuel a furnace holds, in real minutes |
| `ScoopDrawAtFullWind` | `32` | Wind scoop push in full wind, as blocks of height |
| `ExtractorDrawAtFullWind` | `32` | Wind extractor pull in full wind, as blocks of height |

## Asphyxia: Rebreathed
| Setting | Default | What it does |
|---|---|---|
| `AsphyxiaIntegration` | `true` | Act as Asphyxia's ventilation layer when it's installed. Off runs both mods' gases side by side. |
| `AsphyxiaClearShare` | `0.5` | Share of gas removed per spot per draft pass, at full strength |
| `AsphyxiaClearSpotsPerPass` | `48` | Spots cleared per player per draft pass |

## Performance
| Setting | Default | What it does |
|---|---|---|
| `SimChunksPerTick` | `16` | Gas chunks simulated per half second |
| `DraftSearchRadius` | `32` | Cells (2 blocks each) searched around each player for drafts |
| `DraftMaxCells` | `30000` | Most open cells explored per player per draft pass |
| `LightScanRadiusChunks` | `2` | Chunks around players checked for lights in gas |
