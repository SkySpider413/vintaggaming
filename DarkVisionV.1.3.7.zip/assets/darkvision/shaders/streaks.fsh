#version 330 core

uniform sampler2D streakTex;
uniform float streaksIntensity;

in vec2 texCoord;
out vec4 outColor;

void main()
{
    if (streaksIntensity <= 0.0) {
        outColor = vec4(0.0);
        return;
    }

    outColor = vec4(texture(streakTex, texCoord).rgb * streaksIntensity, 1.0);
}