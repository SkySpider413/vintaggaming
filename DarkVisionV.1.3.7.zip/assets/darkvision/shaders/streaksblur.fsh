#version 330 core

uniform sampler2D prevTex;
uniform sampler2D glowTex;
uniform sampler2D primaryScene;
uniform sampler2D depthTex;
uniform sampler2D seedPrevTex;
uniform sampler2D transparentTex;
uniform float streaksLength;
uniform float streaksIntensity;
uniform float streaksActivation;
uniform float stride;
uniform int passIndex;
uniform int dirIndex;

in vec2 texCoord;
out vec4 outColor;

const float NEAR = 0.1;
const float FAR = 1000.0;
const float STREAK_WEIGHT = 0.4;

float linearDepth(float depth)
{
    float z = depth * 2.0 - 1.0;
    return (2.0 * NEAR * FAR) / (FAR + NEAR - z * (FAR - NEAR));
}

void main()
{
    if (passIndex != -1 && streaksIntensity <= 0.0) {
        outColor = vec4(0.0);
        return;
    }

    if (passIndex == -1)
    {
        outColor = texture(prevTex, texCoord);
        return;
    }

    vec2 size = vec2(textureSize(prevTex, 0));
    vec2 texelSize = 1.0 / size;

    float aspect = size.x / size.y;
    vec2 correct = vec2(1.0, aspect);

    vec2 dir;
    switch (dirIndex) {
        case 0: dir = normalize(vec2(1.0,  0.0)  * correct); break;
        case 1: dir = normalize(vec2(1.0,  0.3) * correct); break;
        case 2: dir = normalize(vec2(1.0, -0.3) * correct); break;
        //case 3: dir = normalize(vec2(0.0,  1.0)  * correct); break;
    }
    vec2 offset = dir * texelSize * streaksLength * stride;

    if (passIndex == 0)
    {
        float depth = texture(depthTex, texCoord).r;
        float isSky = step(0.9999, depth);
        float distFade = smoothstep(6.0, 80.0, linearDepth(depth));
        float mask = (1.0 - isSky) * pow(distFade, 2);
        float particleDampen = texture(transparentTex, texCoord).r; // dampens based on transparency. works really well on particles. dampens lanterns too a bit but usable.
        // also has the side effect of strongly dampening anything behind transparent materials.
        mask *= particleDampen;

        float currentGlow = texture(glowTex, texCoord).r;
        float glowFade = step(0.1, currentGlow); // lantern panels are a bit emissive and this makes em show up more instead of just the candle wick. however specular sheen also uses this for whatever the fuck reason.
        currentGlow = glowFade * mask;

        vec3 scene = texture(primaryScene, texCoord).rgb;

        float previousGlow = texture(seedPrevTex, texCoord).a;
        float smoothedGlow = mix(previousGlow, currentGlow, 0.65); // dampens flickering but introduces a motion blur like effect.

        outColor = vec4(texture(primaryScene, texCoord).rgb * smoothedGlow * streaksActivation, smoothedGlow);
    }
    else
    {
        vec3 result = texture(prevTex, texCoord).rgb;
        result += texture(prevTex, texCoord + offset).rgb * STREAK_WEIGHT;
        result += texture(prevTex, texCoord - offset).rgb * STREAK_WEIGHT;
        outColor = vec4(result, 0.0);
    }
}
